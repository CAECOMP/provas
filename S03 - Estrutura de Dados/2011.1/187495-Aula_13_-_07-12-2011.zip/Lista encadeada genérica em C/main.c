#include <stdio.h>
#include <stdlib.h>

#define INT 0
#define FLOAT 1
#define LISTA 2
#define STRING 3

struct nodo {
    int tipo;
    void *val;
    struct nodo *pro;
};
typedef struct nodo TNodo;

void inicializeLI(TNodo **lis)
{
    *lis = NULL;
}

int estaVaziaLI(TNodo *lis)
{
    return lis == NULL;
}

void insiraNoInicioLI(TNodo **lis, int tip, void *val)
{
    TNodo *nn = (TNodo *) malloc(sizeof(TNodo));
    nn->tipo = tip;
    nn->val = val;
    nn->pro = *lis;
    *lis = nn;
}

TNodo *busca(TNodo *lis, int tip, void *val)
{
    while(lis != NULL) {
        if(*((int *)val) == *((int *) lis->val))
//        if(tip == INT || tip == FLOAT && val == lis->val)
            return lis;
        lis = lis->pro;
    }
    return NULL;
}

//void insiraNoFinalLI(TNodo **lis, int val)
//{
//    TNodo *nn = (TNodo *) malloc(sizeof(TNodo));
//    nn->val = val;
//    nn->pro = NULL;
//    if(estaVaziaLI(*lis))
//        *lis = nn;
//    else
//    {
//        TNodo *p = *lis;
//        while(p->pro != NULL)
//            p = p->pro;
//        p->pro = nn;
//    }
//}
//
//void insiraNaPosicaoLI(TNodo **lis, int val, int pos)
//{
//}
//
//int removaDoInicio(TNodo **lis)
//{
//    TNodo *p = *lis;
//    int res = p->val;
//    *lis = p->pro;
//    free(p);
//    return res;
//}
//
//int numeroDeElementos(TNodo *lis)
//{
//    int res = 0;
//    while(lis != NULL)
//    {
//        res++;
//        lis = lis->pro;
//    }
//    return res;
//}
//
//int numeroDeElementosR(TNodo *lis)
//{
//    if(lis == NULL) return 0;
//    return 1+numeroDeElementosR(lis->pro);
//}
//
//int numeroDeOcorrencias(TNodo *lis, int val)
//{
//    int res = 0;
//    while(lis != NULL)
//    {
//        if(lis->val == val)
//            res++;
//        lis = lis->pro;
//    }
//    return res;
//}
//
//int numeroDeOcorrenciasR(TNodo *lis, int val)
//{
//    if(lis == NULL) return 0;
//    if(lis->val == val)
//        return 1+numeroDeOcorrencias(lis->pro,val);
//    else
//        return numeroDeOcorrencias(lis->pro,val);
//}
//
//int removaDoFinal(TNodo **lis)
//{
//    int res;
//    TNodo *p = *lis;
//    TNodo *q = NULL;
//    while(p->pro != NULL)
//    {
//        q = p;
//        p = p->pro;
//    }
//    res = p->val;
//    if(q == NULL)
//        *lis = NULL;
//    else
//        q->pro = NULL;
//    free(p);
//    return res;
//}
//
//int removaDaPosicao(TNodo **lis, int pos)
//{
//    int res;
//    TNodo *p = *lis;
//    TNodo *q = NULL;
//    while(pos>1 && p->pro != NULL)
//    {
//        q = p;
//        p = p->pro;
//        pos--;
//    }
//    res = p->val;
//    if(q == NULL)
//        *lis = p->pro;
//    else
//        q->pro = p->pro;
//    free(p);
//    return res;
//}
//
//void libereLista(TNodo **lis)
//{
//    TNodo *p;
//    while(*lis != NULL)
//    {
//        p = *lis;
//        *lis = p->pro;
//        free(p);
//    }
//}
//
void mostreLI(TNodo *lis)
{
    printf("[");
    if(!estaVaziaLI(lis))
    {
        while(lis != NULL)
        {
            if(lis->tipo == INT)
                printf("%d, ",*((int *) lis->val));
            if(lis->tipo == FLOAT)
                printf("%4.2f, ",*((float *) lis->val));
            if(lis->tipo == LISTA) {
                mostreLI((TNodo *) lis->val);
                printf(", ");
            }
            if(lis->tipo == STRING) {
                printf("\"%s\", ",(char *) lis->val);
            }
            lis = lis->pro;
        }
        printf("\b\b");
    }
    printf("]");
}


int main(int argc, char *argv[])
{
    int i, pos;
    int *pint;
    float *pfloat;
    char str[] = " IFCE ";
    srand(time(NULL));
    TNodo *ml, *lis;
    inicializeLI(&ml);
    inicializeLI(&lis);
    for(i=1;i<=5;i++)
    {
        pint = (int *) malloc(sizeof(int));
        *pint = rand()%100;
        insiraNoInicioLI(&lis,INT,pint);
    }
    //mostreLI(lis); printf("\n");
    pint = (int *) malloc(sizeof(int));
    *pint = 10;
    insiraNoInicioLI(&ml,INT,pint);
    mostreLI(ml); printf("\n");
    pint = (int *) malloc(sizeof(int));
    *pint = 20;
    insiraNoInicioLI(&ml,INT,pint);
    mostreLI(ml); printf("\n");
    pint = (int *) malloc(sizeof(int));
    *pint = 30;
    insiraNoInicioLI(&ml,INT,pint);
    mostreLI(ml); printf("\n");
    pfloat = (float *) malloc(sizeof(float));
    *pfloat = 3.14;
    insiraNoInicioLI(&ml,FLOAT,pfloat);
    mostreLI(ml); printf("\n");

    insiraNoInicioLI(&ml,LISTA,lis);
    mostreLI(ml); printf("\n");

    insiraNoInicioLI(&ml,STRING,str);
    mostreLI(ml); printf("\n");
    TNodo *rb = busca(ml,INT,pint);
    printf("%p\n",rb);
    pint = (int *)rb;
    printf("%d\n",*pint);


//    for(i=0; i<20; i++)
//    {
//        mostreLI(ml); printf("\n");
//        mostreLIR(ml); printf("\n\n");
//        insiraNoFinalLI(&ml,rand()%100);
//    }
//    mostreLI(ml); printf("\n");
//    mostreLIR(ml); printf("\n\n");
//    printf("%d elementos\n",numeroDeElementosR(ml));
//    printf("0 ocorre %d vezes\n",numeroDeOcorrenciasR(ml,0));
//    pos = 10;
//    printf("%d removido da posicao %d\n",removaDaPosicao(&ml,pos),pos);
//    mostreLI(ml); printf("\n");
////    while(!estaVaziaLI(ml))
////    {
////        printf("%d removido\n",removaDoFinal(&ml));
////        mostreLI(ml); printf("\n");
////    }
//    libereLista(&ml);
//    mostreLI(ml); printf("\n");
//    mostreLIR(ml); printf("\n\n");
  system("PAUSE");	
  return 0;
}
