/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package crialistaordenada;

/**
 *
 * @author Administrador
 */
public class ListaOrdenada {
    /** Número de elementos da lista*/
    private int nel;
    /** Array que armazena os elementos */
    private int ele[];
    
    /**
     * Construtor padrão. Cria uma lista vazia com capacidade para
     * 10 elementos
     */
    public ListaOrdenada() {
        nel = 0;
        ele = new int[10];
    }
    
    /**
     * Cria uma lista vazia com a capacidade indicada pelo parâmetro. 
     * @param cap Capacidade da lista 
     */
    public ListaOrdenada(int cap) {
        nel = 0;
        if(cap < 10)
            ele = new int[10];
        else
            ele = new int[cap];
    }
    
    /**
     * Construtor de cópia. Cria uma nova lista que é uma
     * cópia da lista fornecida como parâmetro.
     * @param ldi Lista que será copiada
     */
    public ListaOrdenada(ListaOrdenada ldi) {
        nel = ldi.nel;
        ele = new int[ldi.ele.length];
        System.arraycopy(ldi.ele, 0, this.ele, 0, ldi.nel);
    }
    
    /**
     * Construtor de cópia. Cria uma nova lista que é uma
     * cópia da lista fornecida como parâmetro mas com nova
     * capacidade. Se a nova capacidade não comportar todos os
     * elementos será criada com a capacidade igual ao número
     * de elementos.
     * @param ldi
     * @param cap 
     */
    public ListaOrdenada(ListaOrdenada ldi, int cap) {
        nel = ldi.nel;
        if(nel <= cap)
            ele = new int[cap];
        else
            ele = new int[nel];
        System.arraycopy(ldi.ele, 0, ele, 0, nel);
    }

    /**
     * Método de acesso ao número de elementos dessa lista.
     * @return Número de elementos atualmente na lista.
     */
    public int getNel() {
        return nel;
    }
    
    /**
     * Método de acesso à capacidade máxima da lista.
     * @return A capacidade máxima da lista.
     */
    public int getCap() {
        return ele.length;
    }
    
    /**
     * Método de acesso a um elemento da lista dado o seu índice
     * @param ind Índice do elemento acessado.
     * @return Valor do elemento encontrado no índice
     */
    public int getEle(int ind) {
        return ele[ind];
    }

    /**
     * Método de alteração de um elemento da lista.
     * @param ind Índice do elemento alterado.
     * @param val Novo valor do elemento.
     */
    public void setEle(int ind, int val) {
        ele[ind] = val;
    }
    
    /**
     * Método que verifica se a lista está vazia.
     * @return true se a lista estiver vazia e false se não estiver
     */
    public boolean estaVazia() {
        return nel == 0;
    }
    
    /**
     * Método que verifica se a lista está cheia.
     * @return true se a lista estiver cheia e false se não estiver
     */
    public boolean estaCheia() {
        return nel == ele.length;
    }
    
    /**
     * Insere um elemento no índice especificado.
     * @param ind Índice onde será inserido o elemento
     * @param val Valor do elemento inserido
     */
    public void insira(int val) {
        int ind = 0;
        while(ind<nel  && val>ele[ind])
            ind++;
        for(int i=nel; i>ind; i--)
            ele[i] = ele[i-1];
        ele[ind] = val;
        nel++;
    }
    
    /**
     * Remove o elemento do final da lista
     * @return Valor do elemento removido
     */
    public int removaDoFinal() {
        return ele[--nel];
    }
    
    /**
     * Remove o elemento do início da lista
     * @return Valor do elemento removido
     */
    public int removaDoInicio() {
        int res = ele[0];
        for(int i=0; i<nel-1; i++)
            ele[i] = ele[i+1];
        nel--;
        return res;
    }

    /**
     * Remove o elemento do índice fornecido
     * @param ind Índice do elemento removido
     * @return Valor do elemento removido
     */
    public int removaDoIndice(int ind) {
        int res = ele[ind];
        for(int i=ind; i<nel-1; i++)
            ele[i] = ele[i+1];
        nel--;
        return res;
    }
    
    /**
     * Realiza uma busca linear e retorna o índice do elemento se
     * encontrado. Retorna -1 se não encontrado.
     * @param val Valor buscado
     * @return O índice do elemento buscado. -1 se nao encontrado.
     */
    public int busca(int val) {
        for(int i=0; i<nel; i++)
            if(ele[i] == val)
                return i;
        return -1;
    }
    
    public int buscaBinaria(int val) {
        int ini = 0;
        int fim = nel-1;
        while(fim >= ini)
        {
            int meio = (ini+fim)/2;
            if(val == ele[meio])
                return meio;
            else
                if(val < ele[meio])
                    fim = meio-1;
                else
                    ini = meio+1;
        }
        return -1;
    }
    
    public int buscaBinariaR(int val)
    {
        return bbr(0,nel-1,val);
    }
    
    private int bbr(int ini, int fim, int val)
    {
        if(fim < ini) return -1;
        int meio = (ini+fim)/2;
        if(val == ele[meio]) return meio;
        if(val < ele[meio]) return bbr(ini,meio-1,val);
        return bbr(meio+1,fim,val);
    }
    
    /**
     * Ordena os elementos da lista em ordem crescente
     */
    public void ordena() {
        int pm, aux;
        for(int i=0; i < nel-1; i++)
        {
            pm = i;
            for(int j=i+1; j<nel; j++)
                if(ele[j] < ele[pm])
                    pm = j;
            aux = ele[pm];
            ele[pm] = ele[i];
            ele[i] = aux;
        }
    }
    
    /**
     * Faz a junção dessa lista com lista indicada como
     * parâmetro de entrada.
     * @param ldi Lista que será anexada ao final dessa lista.
     * @return A lista que resulta da junção dessa lista com 
     * a lista fornecida
     */
    public ListaOrdenada juntaListas(ListaOrdenada ldi) {
        ListaOrdenada res = new ListaOrdenada(ele.length + ldi.ele.length);
        res.nel = nel+ldi.nel;
        System.arraycopy(ele, 0, res.ele, 0, nel);
        System.arraycopy(ldi.ele, 0, res.ele, nel, ldi.nel);
        return res;
    }
    
    /**
     * Cria uma string que representa os elementos da lista
     * entre colchetes e separados por vírgula.
     * @return A string que representa a lista.
     */
    @Override
    public String toString() {
        if(estaVazia())
            return "[]";
        String res = "[";
        int i;
        for(i=0; i<nel-1; i++)
            res += ele[i] + ", ";
        return res + ele[i] + "]";
    }
    
    
}
