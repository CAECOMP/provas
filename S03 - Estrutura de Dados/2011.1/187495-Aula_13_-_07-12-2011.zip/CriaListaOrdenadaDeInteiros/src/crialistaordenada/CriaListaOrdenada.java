/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package crialistaordenada;

import java.util.Random;

/**
 *
 * @author Administrador
 */
public class CriaListaOrdenada {
    
    public CriaListaOrdenada() {
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ListaOrdenada ml = new ListaOrdenada(20);
        Random nr = new Random();
        while(!ml.estaCheia())
        {
            ml.insira(nr.nextInt(20));
            System.out.println(ml);
        }
        int vb = 10;
        int rb = ml.buscaBinariaR(vb);
        if(rb > -1)
            System.out.println(vb+" encontrado no índice "+rb );
    }
}
