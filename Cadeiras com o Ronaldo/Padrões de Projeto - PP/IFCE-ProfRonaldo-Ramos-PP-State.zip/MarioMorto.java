/*
  *********************************************************************************************
  * ( )[ ][ ]                                                                                 *
  * [ ][ ]                                                                                    *
  * [ ][ ][ ]                                                                                 *
  * [ ][ ]    - IFCE - Padrões de Projetos - 2021.1 - Prof.Ronaldo 🎷                         *
  *                                                                                           *
  *********************************************************************************************
	*/

public class MarioMorto implements MarioState {

	@Override
	public MarioState pegarCogumelo() {
		return null;

	}

	@Override
	public MarioState pegarFlor() {
		return null;

	}

	@Override
	public MarioState pegarPena() {
		return null;

	}

	@Override
	public MarioState levarDano() {
		return null;

	}

}
