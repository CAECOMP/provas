/*
  *********************************************************************************************
  * ( )[ ][ ]                                                                                 *
  * [ ][ ]                                                                                    *
  * [ ][ ][ ]                                                                                 *
  * [ ][ ]    - IFCE - Padrões de Projetos - 2021.1 - Prof.Ronaldo 🎷                         *
  *                                                                                           *
  *********************************************************************************************
	*/

// Classe geral com os atributos gerais que todo objeto do tipo carro traz
public class CarroProduct {

  public double preco;
  public String dscMotor;
  public int anoDeFabricacao;
  public String modelo;
  public String montadora;

}