/*
  *********************************************************************************************
  * ( )[ ][ ]                                                                                 *
  * [ ][ ]                                                                                    *
  * [ ][ ][ ]                                                                                 *
  * [ ][ ]    - IFCE - Padrões de Projetos - 2021.1 - Prof.Ronaldo 🎷                         *
  *                                                                                           *
  *********************************************************************************************
	*/

public class CanaisEsportes extends AgregadoDeCanais {
  
	public CanaisEsportes() {
		canais.add(new Canal("Esporte ao vivo"));
		canais.add(new Canal("Basquete 2011"));
		canais.add(new Canal("Campeonato Italiano"));
		canais.add(new Canal("Campeonato Espanhol"));
		canais.add(new Canal("Campeonato Brasileiro"));

	}

}