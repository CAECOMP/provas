package inverter;

import javax.jws.WebMethod;
import javax.jws.WebService;

 
//Service Endpoint Interface
@WebService
public interface InverterItf{
 
	@WebMethod String inverter(String name);
 
}
