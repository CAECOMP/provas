/*
  *********************************************************************************************
  * ( )[ ][ ]                                                                                 *
  * [ ][ ]                                                                                    *
  * [ ][ ][ ]                                                                                 *
  * [ ][ ]    - IFCE - Padrões de Projetos - 2021.1 - Prof.Ronaldo 🎷                         *
  *                                                                                           *
  *********************************************************************************************
	*/

public class MusicaMP3 {

	String nome;
	String autor;
	String ano;
	int estrelas;

	public MusicaMP3(String nome, String autor, String ano, int estrela) {

		this.nome = nome;
		this.autor = autor;
		this.ano = ano;
		this.estrelas = estrela;

	}

}