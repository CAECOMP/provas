/*
  *********************************************************************************************
  * ( )[ ][ ]                                                                                 *
  * [ ][ ]                                                                                    *
  * [ ][ ][ ]                                                                                 *
  * [ ][ ]    - IFCE - Padrões de Projetos - 2021.1 - Prof.Ronaldo 🎷                         *
  *                                                                                           *
  *********************************************************************************************
  *
  */

public class ImpressoraEpson implements Impressora {

  public void print(String mensagem) {
    System.out.println("🖨️  Impressora Epson : Mensagem Impressa --->{ 📄" + mensagem + " }");
    
  }

}