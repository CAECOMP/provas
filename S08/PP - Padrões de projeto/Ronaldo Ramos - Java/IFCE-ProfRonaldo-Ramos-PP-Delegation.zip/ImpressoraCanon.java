/*
  *********************************************************************************************
  * ( )[ ][ ]                                                                                 *
  * [ ][ ]                                                                                    *
  * [ ][ ][ ]                                                                                 *
  * [ ][ ]    - IFCE - Padrões de Projetos - 2021.1 - Prof.Ronaldo 🎷                         *
  *                                                                                           *
  *********************************************************************************************
  *
  */

public class ImpressoraCanon implements Impressora {

  public void print(String mensagem) {
    System.out.println("🖨️  Impressora Canon : Mensagem Impressa --->{ 📄" + mensagem + " }");
    
  }

}