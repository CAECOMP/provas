/*
  *********************************************************************************************
  * ( )[ ][ ]                                                                                 *
  * [ ][ ]                                                                                    *
  * [ ][ ][ ]                                                                                 *
  * [ ][ ]    - IFCE - Padrões de Projetos - 2021.1 - Prof.Ronaldo 🎷                         *
  *                                                                                           *
  *********************************************************************************************
	*/

public class ArquivoVideo extends ArquivoComponent {

	public ArquivoVideo(String nomeDoArquivo) {
		this.nomeDoArquivo = nomeDoArquivo;
    
	}

}