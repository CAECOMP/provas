/*
  *********************************************************************************************
  * ( )[ ][ ]                                                                                 *
  * [ ][ ]                                                                                    *
  * [ ][ ][ ]                                                                                 *
  * [ ][ ]    - IFCE - Padrões de Projetos - 2021.1 - Prof.Ronaldo 🎷                         *
  *                                                                                           *
  *********************************************************************************************
	*/

// Contexto de desenho da imagem
public class Ponto {
	public int x, y;

	public Ponto(int x, int y) {
		this.x = x;
		this.y = y;
    
	}

}