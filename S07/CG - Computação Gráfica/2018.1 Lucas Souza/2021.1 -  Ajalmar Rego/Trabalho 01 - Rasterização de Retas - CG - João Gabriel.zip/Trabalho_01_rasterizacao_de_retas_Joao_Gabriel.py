"""
*
********************************************************************************************************************************
* Trabalho_01_rasterizacao_de_retas_Joao_Gabriel.py 30/04/2021 ~(02/05/2021)Atualizado!                                        *
*                                                                                                                              *
*   ( )[][]                                                                                                                    *
*   [][]                                                                                                                       *
*   [][][]                                                                                                                     *
*   [][]   - Computação Gráfica - 2021.1 - Prof.Ajalmar                                                                        *
*                                                                                                                              *
* Copyright 2021 - João Gabriel Carneiro Medeiros,                                                                             *                                                                                                                            
* Instituto Federal de Educação, Ciência e Tecnologia do Ceará - IFCE                                                          *
* Todos os direitos reservados                                                                                                 *
**************************************************************************************************************************************************
*                                                                                                                                                *
*  !!!ATENÇÃO!!! - É preferível que o código seja executado no Windows(de preferência o Windows 10)!                                             * 
*                                                                                                                                                *
*  !!!ATENÇÃO!!! - Esse programa só pode rodar de forma apropriada entra quaisquer versões do Python que estejam entre:                          * 
*                  'Python 3.5x-3.7x'. Eu mesmo rodei e fiz o código na versão 'Python 3.7.9 '. Caso queira, aqui o link para                    *
*                  baixar a veersão 'Python 3.7.9 ': https://www.python.org/downloads/release/python-379/                                        *
*                  (Porque isso é necessário? Veja a seguinte discussão para saber o motivo:                                                     *
*                   https://stackoverflow.com/questions/62204687/python-installing-old-version-of-matplotlib-results-in-freetype-and-png-error)  *
*                                                                                                                                                * 
*       Obs.     - Após baixar a versão 'Python 3.7.9 ' no seu PC, se ele for Windows (de preferência o Windows 10) abra seu                     *
*                  'Prompt de comando' e execute o comando: 'pip3 install matplotlib==3.0.3'. Pronto, agora você poderá 'rodar'                  *
*                  esse código sem problemas.                                                                                                    *
*                                                                                                                                                *
**************************************************************************************************************************************************
*
"""

"""
*
*       *******************
*  ~~~ Bibliotecas utilizada ~~~
*       *******************
*
"""

# Uso elas para criar o arquivo '.EXE' que mandei.
import sys
import os

import math # Uso para a operação de "Chão" com as coordenadas x e y.
import time # Uso para medir o tempode computação que émotrado em alguns dos exemplos.
import random 

import numpy as np # Uso para criar e realizar operações com a matriz deentrada(torna algumas inicializações mais fáceis).

# Uso para a 'plotagem' dos gráficos
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

# Uso para a criação da interface gráfica
from tkinter import *
import tkinter.font as font

# Uso essa função para manipular as imagens e outros arquivos que uso como recursos gráficos para poder criar o '.EXE'.
def resource_path(relative_path):
    try:
    # PyInstaller creates a temp folder and stores path in _MEIPASS
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

"""
*******
*
*        --------------------------------------------------------------------------------------
*   ~~~ Função "produz-fragmento" apresentada na aula do dia 09/04/2021, implementada pelo aluno ~~~
*        --------------------------------------------------------------------------------------
*         - Parâmetros de entrada:
*            . intervalor_MIN_cor_da_reta = Valor que deve estar entre 0 e 256 (0 ≤ Valor ≤ 256).
*                                           (Responsável por estabelecer um intervalo de cores que preencherá a reta rasterizada!)
*
*            . intervalor_MAX_cor_da_reta = Valor que deve estar entre 0 e 256 (0 ≤ Valor ≤ 256).
*                                           (Responsável por estabelecer um intervalo de cores que preencherá a reta rasterizada!)
*
*            . matriz = Matriz de entrada com posições representando o SRD que receberá as posições formadoras da reta rasterizada. 
*            . resolucaoX = Número de linhas da matriz de entrada.
*            . resolucaoY = Número de colunas da matriz de entrada.
*            . x = Coordenada no eixo X formadora da reta rasterizada no SRD.
*            . y = Coordenada no eixo y formadora da reta rasterizada no SRD.
*
*************************************************************************************************
"""
def funcao_produz_fragmento(intervalor_MIN_cor_da_reta, intervalor_MAX_cor_da_reta, matriz, resolucaoX, resolucaoY, x, y):

    # Operação matemática de "Chão(Arredondamento para baixo)" das coordenadas de entrada "x" e "y"
    xm = math.floor(x)
    ym = math.floor(y)

    # Quando x for igual ao limite máximo da resolução estabelecida no eixo X e, assim, ultrapassar em 1 o tamanho máximo de linhas da matriz de entrada
    if (x >= resolucaoX):
        xm = int(math.floor(x)) - 1 # Evita acessos fora ao escopo da matriz de entrada e erros como "IndexError: index out of bounds".

    # Quando y for igual ao limite máximo da resolução estabelecida no eixo Y e, assim, ultrapassar em 1 o tamanho máximo de colunas da matriz de entrada
    if (y >= resolucaoY):
        ym = int(math.floor(y)) - 1 # Evita acessos fora ao escopo da matriz de entrada e erros como "IndexError: index out of bounds".
        
                                    
    # Atribúi-se a posição x,y formadora da reta rasterizada no SRD um valor inteiro e aleatório
    # no intervalo formado pelas variáveis de entrada "intervalor_MIN_cor_da_reta" e "intervalor_MAX_cor_da_reta".
    matriz[ym,xm] = random.randint(intervalor_MIN_cor_da_reta,intervalor_MAX_cor_da_reta)

"""
*******
*
*       -----------------------------------------------------------------------------------------------
*  ~~~ Algoritmo de Rasterização de Retas apresentado na aula do dia 09/04/2021, implementado pelo aluno ~~~
*       -----------------------------------------------------------------------------------------------
*         - Parâmetros de entrada:
*            . intervalo_min_de_Cores_da_Reta = Valor que deve estar entre 0 e 256 (0 ≤ Valor ≤ 256).
*                                              (Estabelece um intervalo de cores que preencherá as posições da matriz que não farão parte da reta rasterizada!)
*
*            . intervalo_max_de_Cores_da_Reta = Valor que deve estar entre 0 e 256 (0 ≤ Valor ≤ 256).
*                                              (Estabelece um intervalo de cores que preencherá as posições da matriz que não farão parte da reta rasterizada!)
*
*            . matriz_de_entrada = Matriz com posições representando o SRD que receberá as posições formadoras da reta rasterizada. 
*            . resolucao_x = Número de linhas da matriz de entrada.
*            . resolucao_y = Número de colunas da matriz de entrada.
*            . x1 = Coordenada de origem no eixo X da reta no SRN.
*            . y1 = Coordenada de origem no eixo Y da reta no SRN.
*            . x2 = Coordenada de destino no eixo X da reta no SRN.
*            . y2 = Coordenada de destino no eixo Y da reta no SRN.
*
************************************************************************************************
"""
def algoritmo_rasterização_de_retas(intervalo_min_de_Cores_da_Reta, intervalo_max_de_Cores_da_Reta, matriz_de_entrada, resolucao_x, resolucao_y, x1, y1, x2, y2):

    '''
     *
     *     ~Obs. Deixei comentado as principais operações e o que fosse "pouco intuivo", mas grande 
     *           parte do algoritmo segue a lógica daquilo que foi apresentado na aula do dia 09/04,
     *           das aulas de tira dúvidas ministradas e do livro. Além disso como o senhor pôde ver
     *           eu deixei os nomes das variáveis bem 'óbvios' com o intuito de entender as operações
     *           condicionais de "if's,else's,elif's e os while's". Espero que ajudem na compreensão
     *           do código kkkkk.
     *           (Qualquer coisa, desculpe qualquer forma de implementação ineficiente ou 'exagerada' rsrsrs)
     *
    '''

    # Conversão das coordenadas no SRN para o SRD
    coordenada_de_origem_x_SRD = x1 * resolucao_x
    coordenada_de_origem_y_SRD = y1 * resolucao_y

    coordenada_de_destino_x_SRD = x2 * resolucao_x
    coordenada_de_destino_y_SRD = y2 * resolucao_y

    # Cálculo do Δx e Δy apartir das coordenadas no SRD
    deltaX = coordenada_de_destino_x_SRD - coordenada_de_origem_x_SRD
    deltaY = coordenada_de_destino_y_SRD - coordenada_de_origem_y_SRD

    # Chamada da função responsável pela construção dos fragmentos da reta rasterizada no SRD
    funcao_produz_fragmento(intervalo_min_de_Cores_da_Reta, intervalo_max_de_Cores_da_Reta , matriz_de_entrada, resolucao_x, resolucao_y, coordenada_de_origem_x_SRD, coordenada_de_origem_y_SRD)

    if (abs(deltaX) > abs(deltaY)): # Trabalha o caso em que Δx > Δy

        if coordenada_de_origem_x_SRD < coordenada_de_destino_x_SRD:

            while coordenada_de_origem_x_SRD < coordenada_de_destino_x_SRD:

                if deltaY == 0:
                    """
                    *********************************************
                    * Para o caso de Δy = 0 podemos concluir que:
                    *********************************************
                    *   1- m = 0.
                    *   2- b = coordenada_de_origem_y_SRD.
                    *********************************************
                    """

                    coordenada_de_origem_x_SRD = coordenada_de_origem_x_SRD + 1.0

                else:
                    m = deltaY/deltaX
                    b = coordenada_de_origem_y_SRD - (m*coordenada_de_origem_x_SRD)

                    coordenada_de_origem_x_SRD = coordenada_de_origem_x_SRD + 1.0
                    coordenada_de_origem_y_SRD = (m*coordenada_de_origem_x_SRD) + b

                funcao_produz_fragmento(intervalo_min_de_Cores_da_Reta, intervalo_max_de_Cores_da_Reta, matriz_de_entrada, resolucao_x, resolucao_y, coordenada_de_origem_x_SRD, coordenada_de_origem_y_SRD)

        elif coordenada_de_origem_x_SRD > coordenada_de_destino_x_SRD:

            while coordenada_de_origem_x_SRD > coordenada_de_destino_x_SRD:

                if deltaY == 0:
                    """
                    *********************************************
                    * Para o caso de Δy = 0 podemos concluir que:
                    *********************************************
                    *   1- m = 0.
                    *   2- b = coordenada_de_origem_y_SRD.
                    *********************************************
                    """

                    coordenada_de_origem_x_SRD = coordenada_de_origem_x_SRD - 1.0

                else:
                    m = deltaY/deltaX
                    b = coordenada_de_origem_y_SRD - (m*coordenada_de_origem_x_SRD)

                    coordenada_de_origem_x_SRD = coordenada_de_origem_x_SRD - 1.0
                    coordenada_de_origem_y_SRD = (m*coordenada_de_origem_x_SRD) + b

                funcao_produz_fragmento(intervalo_min_de_Cores_da_Reta, intervalo_max_de_Cores_da_Reta, matriz_de_entrada, resolucao_x, resolucao_y, coordenada_de_origem_x_SRD, coordenada_de_origem_y_SRD)

    elif (abs(deltaY) > abs(deltaX)): # Trabalha o caso em que Δy > Δx 

        if coordenada_de_origem_y_SRD < coordenada_de_destino_y_SRD:

            while coordenada_de_origem_y_SRD < (coordenada_de_destino_y_SRD - 1.0):

                if deltaX == 0:
                    """
                    *********************************************
                    * Para o caso de Δy = 0 podemos concluir que:
                    ******************************************************************
                    *   1- m = None (Pois qualquer valor dividido por 0 é indefinido).
                    *   2- b = coordenada_de_origem_y_SRD.
                    ******************************************************************
                    """

                    coordenada_de_origem_y_SRD = coordenada_de_origem_y_SRD + 1.0

                else:
                    m = deltaY/deltaX
                    b = coordenada_de_origem_y_SRD - (m*coordenada_de_origem_x_SRD)

                    coordenada_de_origem_y_SRD = coordenada_de_origem_y_SRD + 1.0
                    coordenada_de_origem_x_SRD = (coordenada_de_origem_y_SRD - b)/m

                funcao_produz_fragmento(intervalo_min_de_Cores_da_Reta, intervalo_max_de_Cores_da_Reta, matriz_de_entrada, resolucao_x, resolucao_y, coordenada_de_origem_x_SRD, coordenada_de_origem_y_SRD)

        elif coordenada_de_origem_y_SRD > coordenada_de_destino_y_SRD:

            while coordenada_de_origem_y_SRD > coordenada_de_destino_y_SRD:

                if deltaX == 0:
                    """
                    *********************************************
                    * Para o caso de Δy = 0 podemos concluir que:
                    ******************************************************************
                    *   1- m = None (Pois qualquer valor dividido por 0 é indefinido).
                    *   2- b = coordenada_de_origem_y_SRD.
                    ******************************************************************
                    """

                    coordenada_de_origem_y_SRD = coordenada_de_origem_y_SRD - 1.0

                else:
                    m = deltaY/deltaX                
                    b = coordenada_de_origem_y_SRD - (m*coordenada_de_origem_x_SRD)

                    coordenada_de_origem_y_SRD = coordenada_de_origem_y_SRD - 1.0
                    coordenada_de_origem_x_SRD = (coordenada_de_origem_y_SRD - b)/m

                funcao_produz_fragmento(intervalo_min_de_Cores_da_Reta, intervalo_max_de_Cores_da_Reta, matriz_de_entrada, resolucao_x, resolucao_y, coordenada_de_origem_x_SRD, coordenada_de_origem_y_SRD)

    elif (abs(deltaY) == abs(deltaX)): # Trabalha o caso em que Δx = Δy

        if (coordenada_de_origem_x_SRD > coordenada_de_destino_x_SRD) and (coordenada_de_origem_y_SRD < coordenada_de_destino_y_SRD):

            while (coordenada_de_origem_x_SRD > coordenada_de_destino_x_SRD) and (coordenada_de_origem_y_SRD < coordenada_de_destino_y_SRD):

                if deltaX == 0 and deltaY == 0:
                    """
                    *********************************************
                    * Para o caso de Δy = 0 podemos concluir que:
                    ******************************************************************
                    *   1- m = None (Pois qualquer valor dividido por 0 é indefinido).
                    *   2- b = coordenada_de_origem_y_SRD.
                    ******************************************************************
                    """

                    coordenada_de_origem_x_SRD = coordenada_de_origem_x_SRD
                    coordenada_de_origem_y_SRD = coordenada_de_origem_y_SRD

                else:
                    m = 1 #Pois ambos os valores de Δx e Δy são iguais nesse caso.
                    b = coordenada_de_origem_y_SRD - coordenada_de_origem_x_SRD

                    coordenada_de_origem_x_SRD = coordenada_de_origem_x_SRD - 1.0
                    coordenada_de_origem_y_SRD = coordenada_de_origem_y_SRD + 1.0 

                funcao_produz_fragmento(intervalo_min_de_Cores_da_Reta, intervalo_max_de_Cores_da_Reta, matriz_de_entrada, resolucao_x, resolucao_y, coordenada_de_origem_x_SRD, coordenada_de_origem_y_SRD)

        elif (coordenada_de_origem_x_SRD < coordenada_de_destino_x_SRD) and (coordenada_de_origem_y_SRD > coordenada_de_destino_y_SRD):

            while (coordenada_de_origem_x_SRD < coordenada_de_destino_x_SRD) and (coordenada_de_origem_y_SRD > coordenada_de_destino_y_SRD):

                if deltaX == 0 and deltaY == 0:
                    """
                    *********************************************
                    * Para o caso de Δy = 0 podemos concluir que:
                    ******************************************************************
                    *   1- m = None (Pois qualquer valor dividido por 0 é indefinido).
                    *   2- b = coordenada_de_origem_y_SRD.
                    ******************************************************************
                    """

                    coordenada_de_origem_x_SRD = coordenada_de_origem_x_SRD
                    coordenada_de_origem_y_SRD = coordenada_de_origem_y_SRD

                else:
                    m = 1 #Pois ambos os valores de Δx e Δy são iguais nesse caso.
                    b = coordenada_de_origem_y_SRD - coordenada_de_origem_x_SRD

                    coordenada_de_origem_x_SRD = coordenada_de_origem_x_SRD + 1.0
                    coordenada_de_origem_y_SRD = coordenada_de_origem_y_SRD - 1.0

                funcao_produz_fragmento(intervalo_min_de_Cores_da_Reta, intervalo_max_de_Cores_da_Reta, matriz_de_entrada, resolucao_x, resolucao_y, coordenada_de_origem_x_SRD, coordenada_de_origem_y_SRD)

        elif (coordenada_de_origem_x_SRD > coordenada_de_destino_x_SRD) and (coordenada_de_origem_y_SRD > coordenada_de_destino_y_SRD):

            while (coordenada_de_origem_x_SRD > coordenada_de_destino_x_SRD) and (coordenada_de_origem_y_SRD > coordenada_de_destino_y_SRD):

                if deltaX == 0 and deltaY == 0:
                    """
                    *********************************************
                    * Para o caso de Δy = 0 podemos concluir que:
                    ******************************************************************
                    *   1- m = None (Pois qualquer valor dividido por 0 é indefinido).
                    *   2- b = coordenada_de_origem_y_SRD.
                    ******************************************************************
                    """

                    coordenada_de_origem_x_SRD = coordenada_de_origem_x_SRD
                    coordenada_de_origem_y_SRD = coordenada_de_origem_y_SRD

                else:
                    m = 1 #Pois ambos os valores de Δx e Δy são iguais nesse caso.
                    b = coordenada_de_origem_y_SRD - coordenada_de_origem_x_SRD

                    coordenada_de_origem_x_SRD = coordenada_de_origem_x_SRD - 1.0
                    coordenada_de_origem_y_SRD = coordenada_de_origem_y_SRD - 1.0

                funcao_produz_fragmento(intervalo_min_de_Cores_da_Reta, intervalo_max_de_Cores_da_Reta, matriz_de_entrada, resolucao_x, resolucao_y, coordenada_de_origem_x_SRD, coordenada_de_origem_y_SRD)

        elif (coordenada_de_origem_x_SRD < coordenada_de_destino_x_SRD) and (coordenada_de_origem_y_SRD < coordenada_de_destino_y_SRD):

            while (coordenada_de_origem_x_SRD < coordenada_de_destino_x_SRD) and (coordenada_de_origem_y_SRD < coordenada_de_destino_y_SRD):

                if deltaX == 0 and deltaY == 0:
                    """
                    *********************************************
                    * Para o caso de Δy = 0 podemos concluir que:
                    ******************************************************************
                    *   1- m = None (Pois qualquer valor dividido por 0 é indefinido).
                    *   2- b = coordenada_de_origem_y_SRD.
                    ******************************************************************
                    """

                    coordenada_de_origem_x_SRD = coordenada_de_origem_x_SRD
                    coordenada_de_origem_y_SRD = coordenada_de_origem_y_SRD

                else:
                    m = 1 #Pois ambos os valores de Δx e Δy são iguais nesse caso.
                    b = coordenada_de_origem_y_SRD - coordenada_de_origem_x_SRD

                    coordenada_de_origem_x_SRD = coordenada_de_origem_x_SRD + 1.0
                    coordenada_de_origem_y_SRD = coordenada_de_origem_y_SRD + 1.0

                funcao_produz_fragmento(intervalo_min_de_Cores_da_Reta, intervalo_max_de_Cores_da_Reta, matriz_de_entrada, resolucao_x, resolucao_y, coordenada_de_origem_x_SRD, coordenada_de_origem_y_SRD)

"""
*******
*
*        -----------------------------------------------------------
*   ~~~ Função "plotagem_de_retas_exemplo_01" implementada pelo aluno ~~~
*        -----------------------------------------------------------
*         - Parâmetros de entrada: Nenhum.
*         - Saída:
*            . Quadro Comparativo mostrando diferentes resoluções e tempos de Computação de uma reta rasterizada no SRD com: Δx > Δy.
*
*************************************************************************************************
"""
def plotagem_de_retas_exemplo_01():

    '''
     *
     *     ~Obs. Essa função, como o nome dela mesma já diz kkkk, exibe os resultados obtidos no algoritmo
     *           "algoritmo_rasterização_de_retas" para uma certa entrada de testes.Deixei os nomes das 
     *           variáveis bem 'óbvios' com o intuito de entender as operações condicionais de "if's,
     *           else's,elif's e os while's". Espero que ajudem na compreensão do código kkkkk.
     *           (Qualquer coisa, desculpe qualquer forma de implementação ineficiente ou 'exagerada' rsrsrs)
     *
    '''

    # Criando múltiplos gráficos na mesma janela de exibição usando do Matplotlib.
    fig, axs = plt.subplots( 3, 4, squeeze=False)

    # Ajuste dos títulos da janela e da figura exibida nela.
    fig.suptitle('[Quadro Comparativo - Diferentes Resoluções e Tempos de Computação de Reta Rasterizada com: Δx > Δy] - No SRD', y=0.99, fontsize=6, fontweight="bold")
    fig.canvas.manager.set_window_title('Quadro Comparativo - Diferentes Resoluções e Tempos de Computação de Reta Rasterizada com: Δx > Δy')

    # Ajuste dos espaçamentos (x,y) entre os gráficos plotados.
    fig.tight_layout(pad=1.4,w_pad=-1.0)
    gs1 = gridspec.GridSpec(1, 2)
    gs1.update(wspace=0.025, hspace=0.05)

    #
    #Imagem - 01 - //////////////////////////////////////////////////////////:
    #

    #Resolução 'teste' de entrada
    resolucao_x = 20
    resolucao_y = 15

    #Coordenadas 'teste' de entrada
    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.8
    coordenada_y2_SRN = 0.3

    #Matriz 'teste' de entrada
    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))# Matriz de entrada recebe o método do Numpy(np) "np.random.randint()" que gera uma tupla
                                                                         # de tamanho especificado pelas resoluções 'teste' de entrada local nessa função e preenchida
                                                                         # com valores de um intervalo entre '0 e 40' ou qualquer outro especificado.
    
    inicio = time.time() # Mede o tempo de execução do algoritmo de rasterização no início 
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time() # Mede o tempo de execução do algoritmo de rasterização no fim 

    # Cria o gráfico na janela na posição "[0,0]"
    axs[0,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')# Esse 'cmap' é o que dá as cores na reta e no resto
                                                                                                               # dos gráficos. é por isso que fiz as posições da matriz
                                                                                                               # receberem "intervalos" de números 'randomicamente',
                                                                                                               # Porque ao fazer isso o cmap escolhido (aqui escolhi
                                                                                                               # o padrão: 'viridis' ) vai preencher as posições com
                                                                                                               # cores diferentes em tonalidades mas pertencentes a uma
                                                                                                               # faixa semelhante no cmap, dando aqueles efeitos de retas
                                                                                                               # coloridas que é mostrado.
                                                                                                               # *(Também fiz isso para mostrar melhor os "píxeis na
                                                                                                               #  imagem")

    # Ajusta o 'título' do gráfico na janela na posição "[0,0]"
    axs[0,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")

    # Ajusta um texto que informa o tempo de computação levado na rasterização do gráfico na janela na posição "[0,0]"
    axs[0,0].text(0.0,-0.18, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[0,0].transAxes)

    #
    #Imagem - 02 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 40
    resolucao_y = 30

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[0,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[0,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[0,1].text(0.0,-0.18, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[0,1].transAxes)

    #
    #Imagem - 03 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 80
    resolucao_y = 60

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[0,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[0,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[0,2].text(0.0,-0.18, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[0,2].transAxes)

    #
    #Imagem - 04 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 160
    resolucao_y = 120

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[0,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[0,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[0,3].text(0.0,-0.18, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[0,3].transAxes)

    #
    #Imagem - 05 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 320
    resolucao_y = 240

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[1,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[1,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (QVGA) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[1,0].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[1,0].transAxes)

    #
    #Imagem - 06 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 640
    resolucao_y = 360

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[1,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[1,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (360p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[1,1].text(0.0,-0.185, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[1,1].transAxes)
    
    #
    #Imagem - 07 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 640
    resolucao_y = 480

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[1,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[1,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (VGA-Padrão) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[1,2].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[1,2].transAxes)

    #
    #Imagem - 08 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 1280
    resolucao_y = 720

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[1,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[1,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (WXGA-HD/720p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[1,3].text(0.0,-0.185, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[1,3].transAxes)

    #
    #Imagem - 09 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 1920
    resolucao_y = 1080

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[2,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[2,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (FULL HD/1080p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[2,0].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[2,0].transAxes)

    #
    #Imagem - 10 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 3840
    resolucao_y = 2160

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[2,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[2,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (4K Ultra HD/2160p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[2,1].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[2,1].transAxes)
    
    #
    #Imagem - 11 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 7680
    resolucao_y = 4320

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[2,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[2,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (8K UHDTV/4320p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[2,2].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[2,2].transAxes)

    #
    #Imagem - 12 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 10240 
    resolucao_y = 4320

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[2,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[2,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (10K UHDTV) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[2,3].text(0.0,-0.39, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[2,3].transAxes)


    plt.show(block=False)# Se 'plot.show(block=True)', só será possível exibir uma janela do Matplotlib, ao fazer 'plot.show(block=False)' posso
                         # exibir mais de uma janela em diferentes funções e muito mais. Aqui um link de uma discussão que explica:
                         # https://stackoverflow.com/questions/31686530/matplotlib-generate-a-new-graph-in-a-new-window-for-subsequent-program-runs

"""
*******
*
*        -----------------------------------------------------------
*   ~~~ Função "plotagem_de_retas_exemplo_02" implementada pelo aluno ~~~
*        -----------------------------------------------------------
*         - Parâmetros de entrada: Nenhum.
*         - Saída:
*            . Quadro Comparativo mostrando diferentes resoluções e tempos de Computação de uma reta rasterizada no SRD com: Δy > Δx.
*
*************************************************************************************************
"""
def plotagem_de_retas_exemplo_02():

    '''
     *
     *     ~Obs. Essa função, como o nome dela mesma já diz kkkk, exibe os resultados obtidos no algoritmo
     *           "algoritmo_rasterização_de_retas" para uma certa entrada de testes.Deixei os nomes das 
     *           variáveis bem 'óbvios' com o intuito de entender as operações condicionais de "if's,
     *           else's,elif's e os while's". Espero que ajudem na compreensão do código kkkkk.
     *           (Qualquer coisa, desculpe qualquer forma de implementação ineficiente ou 'exagerada' rsrsrs)
     *
    '''

    fig, axs = plt.subplots( 3, 4, squeeze=False)

    fig.suptitle('[Quadro Comparativo - Diferentes Resoluções e Tempos de Computação de Reta Rasterizada com: Δy > Δx] - No SRD', y=0.99, fontsize=6, fontweight="bold")

    fig.canvas.manager.set_window_title('Quadro Comparativo - Diferentes Resoluções e Tempos de Computação de Reta Rasterizada com: Δy > Δx')

    fig.tight_layout(pad=1.4,w_pad=-1.0)

    gs1 = gridspec.GridSpec(1, 2)
    gs1.update(wspace=0.025, hspace=0.05)

    #
    #Imagem - 01 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 20
    resolucao_y = 15

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.3
    coordenada_y2_SRN = 0.8

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[0,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[0,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[0,0].text(0.0,-0.18, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[0,0].transAxes)

    #ax1[0][0].grid(color='white')

    #
    #Imagem - 02 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 40
    resolucao_y = 30

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[0,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[0,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[0,1].text(0.0,-0.18, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[0,1].transAxes)

    #
    #Imagem - 03 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 80
    resolucao_y = 60

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[0,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[0,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[0,2].text(0.0,-0.18, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[0,2].transAxes)

    #
    #Imagem - 04 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 160
    resolucao_y = 120

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[0,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[0,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[0,3].text(0.0,-0.18, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[0,3].transAxes)

    #
    #Imagem - 05 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 320
    resolucao_y = 240

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[1,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[1,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (QVGA) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[1,0].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[1,0].transAxes)

    #
    #Imagem - 06 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 640
    resolucao_y = 360

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[1,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[1,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (360p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[1,1].text(0.0,-0.185, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[1,1].transAxes)
    
    #
    #Imagem - 07 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 640
    resolucao_y = 480

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[1,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[1,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (VGA-Padrão) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[1,2].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[1,2].transAxes)

    #
    #Imagem - 08 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 1280
    resolucao_y = 720

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[1,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[1,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (WXGA-HD/720p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[1,3].text(0.0,-0.185, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[1,3].transAxes)

    #
    #Imagem - 09 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 1920
    resolucao_y = 1080

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[2,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[2,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (FULL HD/1080p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[2,0].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[2,0].transAxes)

    #
    #Imagem - 10 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 3840
    resolucao_y = 2160

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[2,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[2,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (4K Ultra HD/2160p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[2,1].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[2,1].transAxes)
    
    #
    #Imagem - 11 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 7680
    resolucao_y = 4320

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[2,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[2,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (8K UHDTV/4320p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[2,2].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[2,2].transAxes)

    #
    #Imagem - 12 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 10240 
    resolucao_y = 4320

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[2,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[2,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (10K UHDTV) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[2,3].text(0.0,-0.39, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[2,3].transAxes)

    plt.show(block=False)

"""
*******
*
*        -----------------------------------------------------------
*   ~~~ Função "plotagem_de_retas_exemplo_03" implementada pelo aluno ~~~
*        -----------------------------------------------------------
*         - Parâmetros de entrada: Nenhum.
*         - Saída:
*            . Quadro Comparativo mostrando diferentes resoluções e tempos de Computação de uma reta rasterizada no SRD com: Δy = Δx.
*
*************************************************************************************************
"""
def plotagem_de_retas_exemplo_03():

    '''
     *
     *     ~Obs. Essa função, como o nome dela mesma já diz kkkk, exibe os resultados obtidos no algoritmo
     *           "algoritmo_rasterização_de_retas" para uma certa entrada de testes.Deixei os nomes das 
     *           variáveis bem 'óbvios' com o intuito de entender as operações condicionais de "if's,
     *           else's,elif's e os while's". Espero que ajudem na compreensão do código kkkkk.
     *           (Qualquer coisa, desculpe qualquer forma de implementação ineficiente ou 'exagerada' rsrsrs)
     *
    '''

    fig, axs = plt.subplots( 3, 4, squeeze=False)

    fig.suptitle('[Quadro Comparativo - Diferentes Resoluções e Tempos de Computação de Reta Rasterizada com: Δy = Δx] - No SRD', y=0.99, fontsize=6, fontweight="bold")

    fig.canvas.manager.set_window_title('Quadro Comparativo - Diferentes Resoluções e Tempos de Computação de Reta Rasterizada com: Δy = Δx')

    fig.tight_layout(pad=1.4,w_pad=-1.0)

    gs1 = gridspec.GridSpec(1, 2)
    gs1.update(wspace=0.025, hspace=0.05)

    #
    #Imagem - 01 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 20
    resolucao_y = 15

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[0,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[0,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[0,0].text(0.0,-0.18, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[0,0].transAxes)

    #ax1[0][0].grid(color='white')

    #
    #Imagem - 02 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 40
    resolucao_y = 30

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[0,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[0,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[0,1].text(0.0,-0.18, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[0,1].transAxes)

    #
    #Imagem - 03 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 80
    resolucao_y = 60

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[0,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[0,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[0,2].text(0.0,-0.18, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[0,2].transAxes)

    #
    #Imagem - 04 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 160
    resolucao_y = 120

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[0,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[0,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[0,3].text(0.0,-0.18, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[0,3].transAxes)

    #
    #Imagem - 05 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 320
    resolucao_y = 240

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[1,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[1,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (QVGA) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[1,0].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[1,0].transAxes)

    #
    #Imagem - 06 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 640
    resolucao_y = 360

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[1,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[1,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (360p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[1,1].text(0.0,-0.185, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[1,1].transAxes)
    
    #
    #Imagem - 07 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 640
    resolucao_y = 480

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[1,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[1,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (VGA-Padrão) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[1,2].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[1,2].transAxes)

    #
    #Imagem - 08 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 1280
    resolucao_y = 720

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[1,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[1,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (WXGA-HD/720p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[1,3].text(0.0,-0.185, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[1,3].transAxes)

    #
    #Imagem - 09 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 1920
    resolucao_y = 1080

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[2,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[2,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (FULL HD/1080p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[2,0].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[2,0].transAxes)

    #
    #Imagem - 10 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 3840
    resolucao_y = 2160

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[2,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[2,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (4K Ultra HD/2160p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[2,1].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[2,1].transAxes)
    
    #
    #Imagem - 11 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 7680
    resolucao_y = 4320

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[2,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[2,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (8K UHDTV/4320p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[2,2].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[2,2].transAxes)

    #
    #Imagem - 12 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 10240 
    resolucao_y = 4320

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[2,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[2,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (10K UHDTV) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[2,3].text(0.0,-0.39, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[2,3].transAxes)

    plt.show(block=False)

"""
*******
*
*        -----------------------------------------------------------
*   ~~~ Função "plotagem_de_retas_exemplo_04" implementada pelo aluno ~~~
*        -----------------------------------------------------------
*         - Parâmetros de entrada: Nenhum.
*         - Saída:
*            . Quadro Comparativo mostrando diferentes resoluções e tempos de Computação de uma reta rasterizada no SRD com: Δx = 0.
*
*************************************************************************************************
"""
def plotagem_de_retas_exemplo_04():

    '''
     *
     *     ~Obs. Essa função, como o nome dela mesma já diz kkkk, exibe os resultados obtidos no algoritmo
     *           "algoritmo_rasterização_de_retas" para uma certa entrada de testes.Deixei os nomes das 
     *           variáveis bem 'óbvios' com o intuito de entender as operações condicionais de "if's,
     *           else's,elif's e os while's". Espero que ajudem na compreensão do código kkkkk.
     *           (Qualquer coisa, desculpe qualquer forma de implementação ineficiente ou 'exagerada' rsrsrs)
     *
    '''

    fig, axs = plt.subplots( 3, 4, squeeze=False)

    fig.suptitle('[Quadro Comparativo - Diferentes Resoluções e Tempos de Computação de Reta Rasterizada com: Δx = 0] - No SRD', y=0.99, fontsize=6, fontweight="bold")

    fig.canvas.manager.set_window_title('Quadro Comparativo - Diferentes Resoluções e Tempos de Computação de Reta Rasterizada com: Δx = 0')

    fig.tight_layout(pad=1.4,w_pad=-1.0)

    gs1 = gridspec.GridSpec(1, 2)
    gs1.update(wspace=0.025, hspace=0.05)

    #
    #Imagem - 01 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 20
    resolucao_y = 15

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[0,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[0,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[0,0].text(0.0,-0.18, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[0,0].transAxes)

    #ax1[0][0].grid(color='white')

    #
    #Imagem - 02 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 40
    resolucao_y = 30

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[0,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[0,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[0,1].text(0.0,-0.18, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[0,1].transAxes)

    #
    #Imagem - 03 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 80
    resolucao_y = 60

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[0,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[0,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[0,2].text(0.0,-0.18, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[0,2].transAxes)

    #
    #Imagem - 04 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 160
    resolucao_y = 120

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[0,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[0,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[0,3].text(0.0,-0.18, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[0,3].transAxes)

    #
    #Imagem - 05 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 320
    resolucao_y = 240

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[1,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[1,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (QVGA) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[1,0].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[1,0].transAxes)

    #
    #Imagem - 06 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 640
    resolucao_y = 360

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[1,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[1,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (360p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[1,1].text(0.0,-0.185, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[1,1].transAxes)
    
    #
    #Imagem - 07 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 640
    resolucao_y = 480

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[1,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[1,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (VGA-Padrão) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[1,2].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[1,2].transAxes)

    #
    #Imagem - 08 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 1280
    resolucao_y = 720

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[1,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[1,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (WXGA-HD/720p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[1,3].text(0.0,-0.185, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[1,3].transAxes)

    #
    #Imagem - 09 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 1920
    resolucao_y = 1080

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[2,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[2,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (FULL HD/1080p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[2,0].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[2,0].transAxes)

    #
    #Imagem - 10 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 3840
    resolucao_y = 2160

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[2,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[2,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (4K Ultra HD/2160p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[2,1].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[2,1].transAxes)
    
    #
    #Imagem - 11 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 7680
    resolucao_y = 4320

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[2,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[2,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (8K UHDTV/4320p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[2,2].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[2,2].transAxes)

    #
    #Imagem - 12 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 10240 
    resolucao_y = 4320

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[2,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[2,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (10K UHDTV) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[2,3].text(0.0,-0.39, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[2,3].transAxes)

    plt.show(block=False)

"""
*******
*
*        -----------------------------------------------------------
*   ~~~ Função "plotagem_de_retas_exemplo_05" implementada pelo aluno ~~~
*        -----------------------------------------------------------
*         - Parâmetros de entrada: Nenhum.
*         - Saída:
*            . Quadro Comparativo mostrando diferentes resoluções e tempos de Computação de uma reta rasterizada no SRD com: Δy = 0.
*
*************************************************************************************************
"""
def plotagem_de_retas_exemplo_05():

    '''
     *
     *     ~Obs. Essa função, como o nome dela mesma já diz kkkk, exibe os resultados obtidos no algoritmo
     *           "algoritmo_rasterização_de_retas" para uma certa entrada de testes.Deixei os nomes das 
     *           variáveis bem 'óbvios' com o intuito de entender as operações condicionais de "if's,
     *           else's,elif's e os while's". Espero que ajudem na compreensão do código kkkkk.
     *           (Qualquer coisa, desculpe qualquer forma de implementação ineficiente ou 'exagerada' rsrsrs)
     *
    '''

    fig, axs = plt.subplots( 3, 4, squeeze=False)

    fig.suptitle('[Quadro Comparativo - Diferentes Resoluções e Tempos de Computação de Reta Rasterizada com: Δy = 0] - No SRD', y=0.99, fontsize=6, fontweight="bold")

    fig.canvas.manager.set_window_title('Quadro Comparativo - Diferentes Resoluções e Tempos de Computação de Reta Rasterizada com: Δy = 0')

    fig.tight_layout(pad=1.4,w_pad=-1.0)

    gs1 = gridspec.GridSpec(1, 2)
    gs1.update(wspace=0.025, hspace=0.05)

    #
    #Imagem - 01 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 20
    resolucao_y = 15

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.5

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.5

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[0,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[0,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[0,0].text(0.0,-0.18, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[0,0].transAxes)

    #ax1[0][0].grid(color='white')

    #
    #Imagem - 02 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 40
    resolucao_y = 30

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[0,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[0,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[0,1].text(0.0,-0.18, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[0,1].transAxes)

    #
    #Imagem - 03 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 80
    resolucao_y = 60

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[0,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[0,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[0,2].text(0.0,-0.18, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[0,2].transAxes)

    #
    #Imagem - 04 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 160
    resolucao_y = 120

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[0,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[0,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[0,3].text(0.0,-0.18, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[0,3].transAxes)

    #
    #Imagem - 05 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 320
    resolucao_y = 240

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[1,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[1,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (QVGA) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[1,0].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[1,0].transAxes)

    #
    #Imagem - 06 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 640
    resolucao_y = 360

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[1,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[1,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (360p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[1,1].text(0.0,-0.185, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[1,1].transAxes)
    
    #
    #Imagem - 07 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 640
    resolucao_y = 480

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[1,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[1,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (VGA-Padrão) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[1,2].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[1,2].transAxes)

    #
    #Imagem - 08 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 1280
    resolucao_y = 720

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[1,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[1,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (WXGA-HD/720p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[1,3].text(0.0,-0.185, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[1,3].transAxes)

    #
    #Imagem - 09 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 1920
    resolucao_y = 1080

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[2,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[2,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (FULL HD/1080p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[2,0].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[2,0].transAxes)

    #
    #Imagem - 10 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 3840
    resolucao_y = 2160

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[2,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[2,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (4K Ultra HD/2160p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[2,1].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[2,1].transAxes)
    
    #
    #Imagem - 11 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 7680
    resolucao_y = 4320

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[2,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[2,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (8K UHDTV/4320p) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[2,2].text(0.0,-0.17, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[2,2].transAxes)

    #
    #Imagem - 12 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 10240 
    resolucao_y = 4320

    matriz_de_entrada = np.random.randint(0,40,(resolucao_y,resolucao_x))

    
    inicio = time.time()
    algoritmo_rasterização_de_retas(200,255,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    fim = time.time()
    
    axs[2,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='viridis')
    axs[2,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (10K UHDTV) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[2,3].text(0.0,-0.39, "Tempo de execução do algoritmo\npara rasterização da reta: "+str(fim-inicio)+"s", size=6, ha="left", va="top", transform=axs[2,3].transAxes)

    plt.show(block=False)

"""
*******
*
*        -----------------------------------------------------------
*   ~~~ Função "plotagem_de_retas_exemplo_06" implementada pelo aluno ~~~
*        -----------------------------------------------------------
*         - Parâmetros de entrada: Nenhum.
*         - Saída:
*            . Quadro Comparativo mostrando diferentes resoluções de retas rasterizadas no SRD
*              com: Δx ou Δy = 0 e próximas as bordas do plano X ou Y.
*
*************************************************************************************************
"""
def plotagem_de_retas_exemplo_06():

    '''
     *
     *     ~Obs. Essa função, como o nome dela mesma já diz kkkk, exibe os resultados obtidos no algoritmo
     *           "algoritmo_rasterização_de_retas" para uma certa entrada de testes.Deixei os nomes das 
     *           variáveis bem 'óbvios' com o intuito de entender as operações condicionais de "if's,
     *           else's,elif's e os while's". Espero que ajudem na compreensão do código kkkkk.
     *           (Qualquer coisa, desculpe qualquer forma de implementação ineficiente ou 'exagerada' rsrsrs)
     *
    '''

    fig, axs = plt.subplots( 4, 4, squeeze=False)

    fig.suptitle('[Quadro Comparativo - Diferentes Resoluções de Retas Rasterizadas com: (Δy ou Δx) = 0 e Próximas as Bordas do Plano X ou Y] - No SRD', y=0.99, fontsize=6, fontweight="bold")

    fig.canvas.manager.set_window_title('Quadro Comparativo - Diferentes Resoluções de Retas Rasterizadas com: (Δy ou Δx) = 0 e Próximas as Bordas do Plano X ou Y')

    fig.tight_layout(pad=1.4,w_pad=-3.0)

    gs1 = gridspec.GridSpec(1, 2)
    gs1.update(wspace=0.025, hspace=0.05)

    #
    #Imagem - 01 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 10
    resolucao_y = 7

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 1.0

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x)) #cuidaco com os colormaps miscellaneous, as suas cores não estão nos mesmos intervalos!


    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[0,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[0,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[0,0].text(0.0,-0.25, "*Coordenadas da Reta - SRD: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+") --> ("
                  +str(coordenada_x2_SRN*resolucao_x)+","+str(coordenada_y2_SRN*resolucao_y)+")\nΔx = "+str((coordenada_x2_SRN*resolucao_x)-(coordenada_x1_SRN*resolucao_x))
                  +"  e  Δy = "+str((coordenada_y2_SRN*resolucao_y)-(coordenada_y1_SRN*resolucao_y)), size=6, ha="left", va="top", transform=axs[0,0].transAxes)  

    #
    #Imagem - 02 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 20
    resolucao_y = 15

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 1.0

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x)) #cuidaco com os colormaps miscellaneous, as suas cores não estão nos mesmos intervalos!


    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[0,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[0,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[0,1].text(0.0,-0.25, "*Coordenadas da Reta - SRD: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+") --> ("
                  +str(coordenada_x2_SRN*resolucao_x)+","+str(coordenada_y2_SRN*resolucao_y)+")\nΔx = "+str((coordenada_x2_SRN*resolucao_x)-(coordenada_x1_SRN*resolucao_x))
                  +"  e  Δy = "+str((coordenada_y2_SRN*resolucao_y)-(coordenada_y1_SRN*resolucao_y)), size=6, ha="left", va="top", transform=axs[0,1].transAxes)   

    #
    #Imagem - 03 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 40
    resolucao_y = 30

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 1.0

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x)) #cuidaco com os colormaps miscellaneous, as suas cores não estão nos mesmos intervalos!


    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[0,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[0,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[0,2].text(0.0,-0.25, "*Coordenadas da Reta - SRD: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+") --> ("
                  +str(coordenada_x2_SRN*resolucao_x)+","+str(coordenada_y2_SRN*resolucao_y)+")\nΔx = "+str((coordenada_x2_SRN*resolucao_x)-(coordenada_x1_SRN*resolucao_x))
                  +"  e  Δy = "+str((coordenada_y2_SRN*resolucao_y)-(coordenada_y1_SRN*resolucao_y)), size=6, ha="left", va="top", transform=axs[0,2].transAxes)

    #
    #Imagem - 04 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 80
    resolucao_y = 60

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 1.0

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x)) #cuidaco com os colormaps miscellaneous, as suas cores não estão nos mesmos intervalos!


    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[0,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[0,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[0,3].text(0.0,-0.25, "*Coordenadas da Reta - SRD: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+") --> ("
                  +str(coordenada_x2_SRN*resolucao_x)+","+str(coordenada_y2_SRN*resolucao_y)+")\nΔx = "+str((coordenada_x2_SRN*resolucao_x)-(coordenada_x1_SRN*resolucao_x))
                  +"  e  Δy = "+str((coordenada_y2_SRN*resolucao_y)-(coordenada_y1_SRN*resolucao_y)), size=6, ha="left", va="top", transform=axs[0,3].transAxes)   

    #
    #Imagem - 05 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 10
    resolucao_y = 7

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x)) #cuidaco com os colormaps miscellaneous, as suas cores não estão nos mesmos intervalos!


    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[1,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[1,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[1,0].text(0.0,-0.25, "*Coordenadas da Reta - SRD: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+") --> ("
                  +str(coordenada_x2_SRN*resolucao_x)+","+str(coordenada_y2_SRN*resolucao_y)+")\nΔx = "+str((coordenada_x2_SRN*resolucao_x)-(coordenada_x1_SRN*resolucao_x))
                  +"  e  Δy = "+str((coordenada_y2_SRN*resolucao_y)-(coordenada_y1_SRN*resolucao_y)), size=6, ha="left", va="top", transform=axs[1,0].transAxes)

    #
    #Imagem - 06 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 20
    resolucao_y = 15

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x)) #cuidaco com os colormaps miscellaneous, as suas cores não estão nos mesmos intervalos!


    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[1,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[1,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[1,1].text(0.0,-0.25, "*Coordenadas da Reta - SRD: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+") --> ("
                  +str(coordenada_x2_SRN*resolucao_x)+","+str(coordenada_y2_SRN*resolucao_y)+")\nΔx = "+str((coordenada_x2_SRN*resolucao_x)-(coordenada_x1_SRN*resolucao_x))
                  +"  e  Δy = "+str((coordenada_y2_SRN*resolucao_y)-(coordenada_y1_SRN*resolucao_y)), size=6, ha="left", va="top", transform=axs[1,1].transAxes)  

    #
    #Imagem - 07 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 40
    resolucao_y = 30

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x)) #cuidaco com os colormaps miscellaneous, as suas cores não estão nos mesmos intervalos!


    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[1,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[1,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[1,2].text(0.0,-0.25, "*Coordenadas da Reta - SRD: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+") --> ("
                  +str(coordenada_x2_SRN*resolucao_x)+","+str(coordenada_y2_SRN*resolucao_y)+")\nΔx = "+str((coordenada_x2_SRN*resolucao_x)-(coordenada_x1_SRN*resolucao_x))
                  +"  e  Δy = "+str((coordenada_y2_SRN*resolucao_y)-(coordenada_y1_SRN*resolucao_y)), size=6, ha="left", va="top", transform=axs[1,2].transAxes)   

    #
    #Imagem - 08 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 80
    resolucao_y = 60

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x)) #cuidaco com os colormaps miscellaneous, as suas cores não estão nos mesmos intervalos!


    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[1,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[1,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[1,3].text(0.0,-0.25, "*Coordenadas da Reta - SRD: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+") --> ("
                  +str(coordenada_x2_SRN*resolucao_x)+","+str(coordenada_y2_SRN*resolucao_y)+")\nΔx = "+str((coordenada_x2_SRN*resolucao_x)-(coordenada_x1_SRN*resolucao_x))
                  +"  e  Δy = "+str((coordenada_y2_SRN*resolucao_y)-(coordenada_y1_SRN*resolucao_y)), size=6, ha="left", va="top", transform=axs[1,3].transAxes)    

    #
    #Imagem - 09 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 10
    resolucao_y = 7

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.0

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x)) #cuidaco com os colormaps miscellaneous, as suas cores não estão nos mesmos intervalos!


    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[2,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[2,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[2,0].text(0.0,-0.25, "*Coordenadas da Reta - SRD: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+") --> ("
                  +str(coordenada_x2_SRN*resolucao_x)+","+str(coordenada_y2_SRN*resolucao_y)+")\nΔx = "+str((coordenada_x2_SRN*resolucao_x)-(coordenada_x1_SRN*resolucao_x))
                  +"  e  Δy = "+str((coordenada_y2_SRN*resolucao_y)-(coordenada_y1_SRN*resolucao_y)), size=6, ha="left", va="top", transform=axs[2,0].transAxes)

    #
    #Imagem - 10 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 20
    resolucao_y = 15

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.0

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x)) #cuidaco com os colormaps miscellaneous, as suas cores não estão nos mesmos intervalos!


    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[2,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[2,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[2,1].text(0.0,-0.25, "*Coordenadas da Reta - SRD: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+") --> ("
                  +str(coordenada_x2_SRN*resolucao_x)+","+str(coordenada_y2_SRN*resolucao_y)+")\nΔx = "+str((coordenada_x2_SRN*resolucao_x)-(coordenada_x1_SRN*resolucao_x))
                  +"  e  Δy = "+str((coordenada_y2_SRN*resolucao_y)-(coordenada_y1_SRN*resolucao_y)), size=6, ha="left", va="top", transform=axs[2,1].transAxes)

    #
    #Imagem - 11 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 40
    resolucao_y = 30

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.0

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x)) #cuidaco com os colormaps miscellaneous, as suas cores não estão nos mesmos intervalos!


    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[2,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[2,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[2,2].text(0.0,-0.25, "*Coordenadas da Reta - SRD: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+") --> ("
                  +str(coordenada_x2_SRN*resolucao_x)+","+str(coordenada_y2_SRN*resolucao_y)+")\nΔx = "+str((coordenada_x2_SRN*resolucao_x)-(coordenada_x1_SRN*resolucao_x))
                  +"  e  Δy = "+str((coordenada_y2_SRN*resolucao_y)-(coordenada_y1_SRN*resolucao_y)), size=6, ha="left", va="top", transform=axs[2,2].transAxes)

    #
    #Imagem - 12 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 80
    resolucao_y = 60

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.0

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x)) #cuidaco com os colormaps miscellaneous, as suas cores não estão nos mesmos intervalos!


    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[2,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[2,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[2,3].text(0.0,-0.25, "*Coordenadas da Reta - SRD: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+") --> ("
                  +str(coordenada_x2_SRN*resolucao_x)+","+str(coordenada_y2_SRN*resolucao_y)+")\nΔx = "+str((coordenada_x2_SRN*resolucao_x)-(coordenada_x1_SRN*resolucao_x))
                  +"  e  Δy = "+str((coordenada_y2_SRN*resolucao_y)-(coordenada_y1_SRN*resolucao_y)), size=6, ha="left", va="top", transform=axs[2,3].transAxes)

    #
    #Imagem - 13 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 10
    resolucao_y = 7

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x)) #cuidaco com os colormaps miscellaneous, as suas cores não estão nos mesmos intervalos!


    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[3,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[3,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[3,0].text(0.0,-0.25, "*Coordenadas da Reta - SRD: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+") --> ("
                  +str(coordenada_x2_SRN*resolucao_x)+","+str(coordenada_y2_SRN*resolucao_y)+")\nΔx = "+str((coordenada_x2_SRN*resolucao_x)-(coordenada_x1_SRN*resolucao_x))
                  +"  e  Δy = "+str((coordenada_y2_SRN*resolucao_y)-(coordenada_y1_SRN*resolucao_y)), size=6, ha="left", va="top", transform=axs[3,0].transAxes)

    #
    #Imagem - 14 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 20
    resolucao_y = 15

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x)) #cuidaco com os colormaps miscellaneous, as suas cores não estão nos mesmos intervalos!


    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[3,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[3,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[3,1].text(0.0,-0.25, "*Coordenadas da Reta - SRD: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+") --> ("
                  +str(coordenada_x2_SRN*resolucao_x)+","+str(coordenada_y2_SRN*resolucao_y)+")\nΔx = "+str((coordenada_x2_SRN*resolucao_x)-(coordenada_x1_SRN*resolucao_x))
                  +"  e  Δy = "+str((coordenada_y2_SRN*resolucao_y)-(coordenada_y1_SRN*resolucao_y)), size=6, ha="left", va="top", transform=axs[3,1].transAxes)

    #
    #Imagem - 15 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 40
    resolucao_y = 30

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x)) #cuidaco com os colormaps miscellaneous, as suas cores não estão nos mesmos intervalos!


    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[3,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[3,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[3,2].text(0.0,-0.25, "*Coordenadas da Reta - SRD: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+") --> ("
                  +str(coordenada_x2_SRN*resolucao_x)+","+str(coordenada_y2_SRN*resolucao_y)+")\nΔx = "+str((coordenada_x2_SRN*resolucao_x)-(coordenada_x1_SRN*resolucao_x))
                  +"  e  Δy = "+str((coordenada_y2_SRN*resolucao_y)-(coordenada_y1_SRN*resolucao_y)), size=6, ha="left", va="top", transform=axs[3,2].transAxes)

    #
    #Imagem - 16 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 80
    resolucao_y = 60

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x))


    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[3,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[3,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")
    axs[3,3].text(0.0,-0.25, "*Coordenadas da Reta - SRD: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+") --> ("
                  +str(coordenada_x2_SRN*resolucao_x)+","+str(coordenada_y2_SRN*resolucao_y)+")\nΔx = "+str((coordenada_x2_SRN*resolucao_x)-(coordenada_x1_SRN*resolucao_x))
                  +"  e  Δy = "+str((coordenada_y2_SRN*resolucao_y)-(coordenada_y1_SRN*resolucao_y)), size=6, ha="left", va="top", transform=axs[3,3].transAxes)

    plt.show(block=False)

"""
*******
*
*        -----------------------------------------------------------
*   ~~~ Função "plotagem_de_retas_exemplo_07" implementada pelo aluno ~~~
*        -----------------------------------------------------------
*         - Parâmetros de entrada: Nenhum.
*         - Saída:
*            . Quadro Comparativo mostrando diferentes resoluções de diferentes retas rasterizadas no SRD
*              com: Δx ou Δy = 0.
*
*************************************************************************************************
"""
def plotagem_de_retas_exemplo_07():

    '''
     *
     *     ~Obs. Essa função, como o nome dela mesma já diz kkkk, exibe os resultados obtidos no algoritmo
     *           "algoritmo_rasterização_de_retas" para uma certa entrada de testes.Deixei os nomes das 
     *           variáveis bem 'óbvios' com o intuito de entender as operações condicionais de "if's,
     *           else's,elif's e os while's". Espero que ajudem na compreensão do código kkkkk.
     *           (Qualquer coisa, desculpe qualquer forma de implementação ineficiente ou 'exagerada' rsrsrs)
     *
    '''

    fig, axs = plt.subplots( 4, 4, squeeze=False)

    fig.suptitle('[Quadro Comparativo - Diferentes Resoluções de Diferentes Retas Rasterizadas com: (Δy ou Δx) = 0] - No SRD', y=0.998, fontsize=6, fontweight="bold")

    fig.canvas.manager.set_window_title('Quadro Comparativo - Diferentes Resoluções de Diferentes Retas Rasterizadas com: (Δy ou Δx) = 0')

    fig.tight_layout()

    gs1 = gridspec.GridSpec(1, 2)
    gs1.update(wspace=0.025, hspace=0.05)

    #
    #Imagem - 01 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 10
    resolucao_y = 7

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x))

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    #1a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.75

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.75

    #2a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.5

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.5

    #3a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.25

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.25

    #4a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.0

    #5a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[0,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[0,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")

    #
    #Imagem - 02 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 20
    resolucao_y = 15

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x))

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    #1a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.75

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.75

    #2a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.5

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.5

    #3a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.25

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.25

    #4a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.0

    #5a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[0,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[0,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")

    #
    #Imagem - 03 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 40
    resolucao_y = 30

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x))

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    #1a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.75

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.75

    #2a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.5

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.5

    #3a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.25

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.25

    #4a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.0

    #5a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[0,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[0,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")

    #
    #Imagem - 04 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 80
    resolucao_y = 60

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x))

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    #1a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.75

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.75

    #2a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.5

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.5

    #3a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.25

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.25

    #4a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.0

    #5a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[0,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[0,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")

    #
    #Imagem - 05 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 10
    resolucao_y = 7

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x))

    coordenada_x1_SRN = 0.1
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.7
    coordenada_y2_SRN = 1.0

    #1a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.2
    coordenada_y1_SRN = 0.75

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 0.75

    #2a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.5

    coordenada_x2_SRN = 0.8
    coordenada_y2_SRN = 0.5

    #3a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.3
    coordenada_y1_SRN = 0.25

    coordenada_x2_SRN = 0.8
    coordenada_y2_SRN = 0.25

    #4a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.2
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.0

    #5a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[1,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[1,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")

    #
    #Imagem - 06 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 20
    resolucao_y = 15

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x))

    coordenada_x1_SRN = 0.1
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.7
    coordenada_y2_SRN = 1.0

    #1a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.2
    coordenada_y1_SRN = 0.75

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 0.75

    #2a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.5

    coordenada_x2_SRN = 0.8
    coordenada_y2_SRN = 0.5

    #3a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.3
    coordenada_y1_SRN = 0.25

    coordenada_x2_SRN = 0.8
    coordenada_y2_SRN = 0.25

    #4a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.2
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.0

    #5a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[1,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[1,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")

    #
    #Imagem - 07 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 40
    resolucao_y = 30

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x))

    coordenada_x1_SRN = 0.1
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.7
    coordenada_y2_SRN = 1.0

    #1a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.2
    coordenada_y1_SRN = 0.75

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 0.75

    #2a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.5

    coordenada_x2_SRN = 0.8
    coordenada_y2_SRN = 0.5

    #3a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.3
    coordenada_y1_SRN = 0.25

    coordenada_x2_SRN = 0.8
    coordenada_y2_SRN = 0.25

    #4a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.2
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.0

    #5a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[1,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[1,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")

    #
    #Imagem - 08 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 80
    resolucao_y = 60

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x))

    coordenada_x1_SRN = 0.1
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.7
    coordenada_y2_SRN = 1.0

    #1a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.2
    coordenada_y1_SRN = 0.75

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 0.75

    #2a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.5

    coordenada_x2_SRN = 0.8
    coordenada_y2_SRN = 0.5

    #3a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.3
    coordenada_y1_SRN = 0.25

    coordenada_x2_SRN = 0.8
    coordenada_y2_SRN = 0.25

    #4a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.2
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.0

    #5a reta horizontal ("de cima para baixo") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[1,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[1,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")

    #
    #Imagem - 09 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 10
    resolucao_y = 7

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x))

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    #1a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.75
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 1.0

    #2a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    #3a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.25
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.25
    coordenada_y2_SRN = 1.0

    #4a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 1.0

    #5a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[2,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[2,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")

    #
    #Imagem - 10 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 20
    resolucao_y = 15

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x))

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    #1a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.75
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 1.0

    #2a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    #3a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.25
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.25
    coordenada_y2_SRN = 1.0

    #4a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 1.0

    #5a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[2,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[2,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")

    #
    #Imagem - 11 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 40
    resolucao_y = 30

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x))

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    #1a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.75
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 1.0

    #2a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    #3a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.25
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.25
    coordenada_y2_SRN = 1.0

    #4a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 1.0

    #5a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[2,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[2,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")

    #
    #Imagem - 12 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 80
    resolucao_y = 60

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x))

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    #1a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.75
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 1.0

    #2a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    #3a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.25
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.25
    coordenada_y2_SRN = 1.0

    #4a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 1.0

    #5a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[2,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[2,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")

    #
    #Imagem - 13 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 10
    resolucao_y = 7

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x))

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.1

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.9

    #1a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.75
    coordenada_y1_SRN = 0.5

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 0.9

    #2a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.3

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    #3a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.3
    coordenada_y1_SRN = 0.3

    coordenada_x2_SRN = 0.3
    coordenada_y2_SRN = 0.8

    #4a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.1
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.1
    coordenada_y2_SRN = 0.7

    #5a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[3,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[3,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")

    #
    #Imagem - 14 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 20
    resolucao_y = 15

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x))

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.1

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.9

    #1a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.75
    coordenada_y1_SRN = 0.5

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 0.9

    #2a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.3

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    #3a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.3
    coordenada_y1_SRN = 0.3

    coordenada_x2_SRN = 0.3
    coordenada_y2_SRN = 0.8

    #4a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.1
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.1
    coordenada_y2_SRN = 0.7

    #5a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[3,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[3,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")

    #
    #Imagem - 15 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 40
    resolucao_y = 30

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x))

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.1

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.9

    #1a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.75
    coordenada_y1_SRN = 0.5

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 0.9

    #2a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.3

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    #3a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.3
    coordenada_y1_SRN = 0.3

    coordenada_x2_SRN = 0.3
    coordenada_y2_SRN = 0.8

    #4a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.1
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.1
    coordenada_y2_SRN = 0.7

    #5a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[3,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[3,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")

    #
    #Imagem - 16 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 80
    resolucao_y = 60

    matriz_de_entrada = np.random.randint(64,65,(resolucao_y,resolucao_x))

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.1

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.9

    #1a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.75
    coordenada_y1_SRN = 0.5

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 0.9

    #2a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.3

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    #3a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.3
    coordenada_y1_SRN = 0.3

    coordenada_x2_SRN = 0.3
    coordenada_y2_SRN = 0.8

    #4a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.1
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.1
    coordenada_y2_SRN = 0.7

    #5a reta vertical ("da direita para a esquerda") na imagem.
    algoritmo_rasterização_de_retas(80,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[3,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gnuplot2')
    axs[3,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=6,fontweight="bold")

    fig.subplots_adjust(hspace=0.35, wspace= -0.6)

    plt.show(block=False)    

"""
*******
*
*        -----------------------------------------------------------
*   ~~~ Função "plotagem_de_retas_exemplo_08" implementada pelo aluno ~~~
*        -----------------------------------------------------------
*         - Parâmetros de entrada: Nenhum.
*         - Saída:
*            . Primeiro exemplo de um quadro Comparativo mostrando diferentes retas no SRD com 
*              origem ou nas coordenadas (0.0,0.0) ou nas coordenadas (1.0,1.0).
*
*************************************************************************************************
"""
def plotagem_de_retas_exemplo_08():

    '''
     *
     *     ~Obs. Essa função, como o nome dela mesma já diz kkkk, exibe os resultados obtidos no algoritmo
     *           "algoritmo_rasterização_de_retas" para uma certa entrada de testes.Deixei os nomes das 
     *           variáveis bem 'óbvios' com o intuito de entender as operações condicionais de "if's,
     *           else's,elif's e os while's". Espero que ajudem na compreensão do código kkkkk.
     *           (Qualquer coisa, desculpe qualquer forma de implementação ineficiente ou 'exagerada' rsrsrs)
     *
    '''

    fig, axs = plt.subplots( 2, 4, squeeze=False) 

    fig.suptitle('[Exemplo 01 - Diferentes Retas com Origem nas Coordenads: (0.0,0.0) ou (1.0,1.0)] - No SRD', y=0.975, fontsize=14, fontweight="bold")

    fig.canvas.manager.set_window_title('Quadro Comparativo - Diferentes Resoluções de Múltiplas Retas Rasterizadas com Origem nas Coordenads: (0.0,0.0) ou (1.0,1.0)')

    fig.tight_layout()

    gs1 = gridspec.GridSpec(1, 2)
    gs1.update(wspace=0.025, hspace=0.05)

    #
    #Imagem - 01 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 40
    resolucao_y = 30

    matriz_de_entrada = np.random.randint(0,2,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 1.0

    #reta vertical na imagem.
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    #1a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(51,70,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    #2a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(10,20,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.5

    #3a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.25
    coordenada_y2_SRN = 1.0

    #4a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(121,150,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.25

    #5a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(151,180,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.0

    #6a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(181,200,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.75

    #7a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(220,241,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 1.0

    #reta horizontal na imagem.
    algoritmo_rasterização_de_retas(242,250,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[0,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar') #gist_stern #gist_ncar
    axs[0,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=10)

    #
    #Imagem - 02 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 80
    resolucao_y = 60

    matriz_de_entrada = np.random.randint(0,2,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 1.0

    #reta vertical na imagem.
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    #1a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(51,70,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    #2a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(10,20,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.5

    #3a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.25
    coordenada_y2_SRN = 1.0

    #4a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(121,150,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.25

    #5a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(151,180,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.0

    #6a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(181,200,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.75

    #7a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(220,241,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 1.0

    #reta horizontal na imagem.
    algoritmo_rasterização_de_retas(242,250,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[0,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar') #gist_stern #gist_ncar
    axs[0,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=10)

    #
    #Imagem - 03 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 160
    resolucao_y = 120

    matriz_de_entrada = np.random.randint(0,2,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 1.0

    #reta vertical na imagem.
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    #1a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(51,70,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    #2a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(10,20,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.5

    #3a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.25
    coordenada_y2_SRN = 1.0

    #4a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(121,150,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.25

    #5a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(151,180,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.0

    #6a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(181,200,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.75

    #7a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(220,241,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 1.0

    #reta horizontal na imagem.
    algoritmo_rasterização_de_retas(242,250,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[0,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar') #gist_stern #gist_ncar
    axs[0,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=10)

    #
    #Imagem - 04 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 320
    resolucao_y = 240

    matriz_de_entrada = np.random.randint(0,2,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 1.0

    #reta vertical na imagem.
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    #1a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(51,70,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    #2a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(10,20,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.5

    #3a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.25
    coordenada_y2_SRN = 1.0

    #4a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(121,150,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.25

    #5a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(151,180,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.0

    #6a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(181,200,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.75

    #7a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(220,241,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 1.0

    #reta horizontal na imagem.
    algoritmo_rasterização_de_retas(242,250,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[0,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar') #gist_stern #gist_ncar
    axs[0,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (QVGA) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=10)

    #
    #Imagem - 05 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 40
    resolucao_y = 30

    matriz_de_entrada = np.random.randint(0,2,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.0

    #reta vertical na imagem.
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 0.0

    #1a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(51,70,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.0

    #2a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(10,20,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.5

    #3a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.25
    coordenada_y2_SRN = 0.0

    #4a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(121,150,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.25

    #5a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(151,180,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 1.0

    #6a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(181,200,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.75

    #7a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(220,241,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 0.0

    #reta horizontal na imagem.
    algoritmo_rasterização_de_retas(242,250,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[1,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar') #gist_stern #gist_ncar
    axs[1,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=10)

    #
    #Imagem - 06 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 80
    resolucao_y = 60

    matriz_de_entrada = np.random.randint(0,2,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.0

    #reta vertical na imagem.
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 0.0

    #1a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(51,70,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.0

    #2a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(10,20,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.5

    #3a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.25
    coordenada_y2_SRN = 0.0

    #4a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(121,150,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.25

    #5a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(151,180,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 1.0

    #6a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(181,200,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.75

    #7a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(220,241,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 0.0

    #reta horizontal na imagem.
    algoritmo_rasterização_de_retas(242,250,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[1,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar') #gist_stern #gist_ncar
    axs[1,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=10)

    #
    #Imagem - 07 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 160
    resolucao_y = 120

    matriz_de_entrada = np.random.randint(0,2,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.0

    #reta vertical na imagem.
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 0.0

    #1a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(51,70,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.0

    #2a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(10,20,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.5

    #3a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.25
    coordenada_y2_SRN = 0.0

    #4a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(121,150,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.25

    #5a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(151,180,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 1.0

    #6a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(181,200,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.75

    #7a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(220,241,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 0.0

    #reta horizontal na imagem.
    algoritmo_rasterização_de_retas(242,250,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[1,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar') #gist_stern #gist_ncar
    axs[1,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=10)

    #
    #Imagem - 08 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 320
    resolucao_y = 240

    matriz_de_entrada = np.random.randint(0,2,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.0

    #reta vertical na imagem.
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 0.0

    #1a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(51,70,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.0

    #2a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(10,20,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.5

    #3a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.25
    coordenada_y2_SRN = 0.0

    #4a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(121,150,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.25

    #5a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(151,180,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 1.0

    #6a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(181,200,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.75

    #7a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(220,241,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 0.0

    #reta horizontal na imagem.
    algoritmo_rasterização_de_retas(242,250,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[1,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar') #gist_stern #gist_ncar
    axs[1,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=10)

    fig.subplots_adjust(hspace=-0.005, wspace= 0.15)

    plt.show(block=False) 

"""
*******
*
*        -----------------------------------------------------------
*   ~~~ Função "plotagem_de_retas_exemplo_09" implementada pelo aluno ~~~
*        -----------------------------------------------------------
*         - Parâmetros de entrada: Nenhum.
*         - Saída:
*            . Segundo exemplo de um quadro Comparativo mostrando diferentes retas no SRD com 
*              origem ou nas coordenadas (1.0,0.0) ou nas coordenadas (0.0,1.0).
*
*************************************************************************************************
"""
def plotagem_de_retas_exemplo_09():

    '''
     *
     *     ~Obs. Essa função, como o nome dela mesma já diz kkkk, exibe os resultados obtidos no algoritmo
     *           "algoritmo_rasterização_de_retas" para uma certa entrada de testes.Deixei os nomes das 
     *           variáveis bem 'óbvios' com o intuito de entender as operações condicionais de "if's,
     *           else's,elif's e os while's". Espero que ajudem na compreensão do código kkkkk.
     *           (Qualquer coisa, desculpe qualquer forma de implementação ineficiente ou 'exagerada' rsrsrs)
     *
    '''

    fig, axs = plt.subplots( 2, 4, squeeze=False)

    fig.suptitle('[Exemplo 02 - Diferentes Retas com Origem nas Coordenadas: (1.0,0.0) ou (0.0,1.0)] - No SRD', y=0.975, fontsize=14, fontweight="bold")

    fig.canvas.manager.set_window_title('Quadro Comparativo - Diferentes Resoluções de Múltiplas Retas Rasterizadas com Origem nas Coordenadas: (1.0,0.0) ou (0.0,1.0)')

    fig.tight_layout()

    gs1 = gridspec.GridSpec(1, 2)
    gs1.update(wspace=0.025, hspace=0.05)

    #
    #Imagem - 01 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 40
    resolucao_y = 30

    matriz_de_entrada = np.random.randint(0,2,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.0

    #reta vertical na imagem.
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 0.0

    #1a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(51,70,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.0

    #2a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(10,20,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.5

    #3a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.25
    coordenada_y2_SRN = 0.0

    #4a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(121,150,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.25

    #5a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(151,180,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 0.0

    #6a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(181,200,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.75

    #7a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(220,241,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    #reta horizontal na imagem.
    algoritmo_rasterização_de_retas(242,250,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[0,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar') #gist_stern #gist_ncar
    axs[0,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=10)

    #
    #Imagem - 02 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 80
    resolucao_y = 60

    matriz_de_entrada = np.random.randint(0,2,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.0

    #reta vertical na imagem.
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 0.0

    #1a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(51,70,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.0

    #2a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(10,20,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.5

    #3a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.25
    coordenada_y2_SRN = 0.0

    #4a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(121,150,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.25

    #5a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(151,180,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 0.0

    #6a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(181,200,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.75

    #7a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(220,241,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    #reta horizontal na imagem.
    algoritmo_rasterização_de_retas(242,250,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[0,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar')
    axs[0,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=10)

    #
    #Imagem - 03 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 160
    resolucao_y = 120

    matriz_de_entrada = np.random.randint(0,2,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.0

    #reta vertical na imagem.
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 0.0

    #1a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(51,70,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.0

    #2a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(10,20,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.5

    #3a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.25
    coordenada_y2_SRN = 0.0

    #4a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(121,150,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.25

    #5a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(151,180,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 0.0

    #6a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(181,200,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.75

    #7a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(220,241,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    #reta horizontal na imagem.
    algoritmo_rasterização_de_retas(242,250,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[0,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar')
    axs[0,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=10)

    #
    #Imagem - 04 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 320
    resolucao_y = 240

    matriz_de_entrada = np.random.randint(0,2,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.0

    #reta vertical na imagem.
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 0.0

    #1a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(51,70,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.0

    #2a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(10,20,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.5

    #3a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.25
    coordenada_y2_SRN = 0.0

    #4a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(121,150,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.25

    #5a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(151,180,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 0.0

    #6a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(181,200,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.75

    #7a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(220,241,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 1.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    #reta horizontal na imagem.
    algoritmo_rasterização_de_retas(242,250,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[0,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar')
    axs[0,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (QVGA) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=10)

    #
    #Imagem - 05 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 40
    resolucao_y = 30

    matriz_de_entrada = np.random.randint(0,2,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    #reta vertical na imagem.
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    #1a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(51,70,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 1.0

    #2a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(10,20,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.5

    #3a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.25
    coordenada_y2_SRN = 1.0

    #4a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(121,150,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.25

    #5a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(151,180,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 1.0

    #6a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(181,200,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.75

    #7a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(220,241,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.0

    #reta horizontal na imagem.
    algoritmo_rasterização_de_retas(242,250,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[1,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar')
    axs[1,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=10)

    #
    #Imagem - 06 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 80
    resolucao_y = 60

    matriz_de_entrada = np.random.randint(0,2,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    #reta vertical na imagem.
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    #1a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(51,70,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 1.0

    #2a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(10,20,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.5

    #3a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.25
    coordenada_y2_SRN = 1.0

    #4a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(121,150,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.25

    #5a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(151,180,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 1.0

    #6a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(181,200,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.75

    #7a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(220,241,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.0

    #reta horizontal na imagem.
    algoritmo_rasterização_de_retas(242,250,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[1,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar')
    axs[1,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=10)

    #
    #Imagem - 07 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 160
    resolucao_y = 120

    matriz_de_entrada = np.random.randint(0,2,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    #reta vertical na imagem.
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    #1a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(51,70,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 1.0

    #2a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(10,20,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.5

    #3a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.25
    coordenada_y2_SRN = 1.0

    #4a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(121,150,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.25

    #5a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(151,180,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 1.0

    #6a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(181,200,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.75

    #7a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(220,241,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.0

    #reta horizontal na imagem.
    algoritmo_rasterização_de_retas(242,250,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[1,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar')
    axs[1,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=10)

    #
    #Imagem - 08 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 320
    resolucao_y = 240

    matriz_de_entrada = np.random.randint(0,2,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    #reta vertical na imagem.
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    #1a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(51,70,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 1.0

    #2a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(10,20,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.5

    #3a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.25
    coordenada_y2_SRN = 1.0

    #4a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(121,150,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.25

    #5a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(151,180,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 1.0

    #6a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(181,200,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.75

    #7a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(220,241,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.0

    #reta horizontal na imagem.
    algoritmo_rasterização_de_retas(242,250,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[1,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar')
    axs[1,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (QVGA) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=10)

    fig.subplots_adjust(hspace=-0.005, wspace= 0.15)

    plt.show(block=False)

"""
*******
*
*        -----------------------------------------------------------
*   ~~~ Função "plotagem_de_retas_exemplo_10" implementada pelo aluno ~~~
*        -----------------------------------------------------------
*         - Parâmetros de entrada: Nenhum.
*         - Saída:
*            . Quadro Comparativo mostrando diferentes resoluções de múltiplas retas diagonais  
*              no SRD.
*
*************************************************************************************************
"""
def plotagem_de_retas_exemplo_10():

    '''
     *
     *     ~Obs. Essa função, como o nome dela mesma já diz kkkk, exibe os resultados obtidos no algoritmo
     *           "algoritmo_rasterização_de_retas" para uma certa entrada de testes.Deixei os nomes das 
     *           variáveis bem 'óbvios' com o intuito de entender as operações condicionais de "if's,
     *           else's,elif's e os while's". Espero que ajudem na compreensão do código kkkkk.
     *           (Qualquer coisa, desculpe qualquer forma de implementação ineficiente ou 'exagerada' rsrsrs)
     *
    '''

    fig, axs = plt.subplots( 2, 4, squeeze=False)

    fig.suptitle('[Quadro Comparativo - Diferentes Resoluções de Múltiplas Retas Rasterizadas na Diagonal] - No SRD', y=0.975, fontsize=12, fontweight="bold")

    fig.canvas.manager.set_window_title('Diferentes Retas Diagonais no Plano de Referência de Coordenadas (x,y): SRD')

    fig.tight_layout()

    gs1 = gridspec.GridSpec(1, 2)
    gs1.update(wspace=0.025, hspace=0.05)

    #
    #Imagem - 01 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 40
    resolucao_y = 30

    matriz_de_entrada = np.random.randint(0,2,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.8

    coordenada_x2_SRN = 0.2
    coordenada_y2_SRN = 1.0

    #1a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.5

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    #2a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(51,70,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.25

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 1.0

    #3a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(200,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    #4a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.25
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.75

    #5a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.5

    #6a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(121,150,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.8
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.2

    #7a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(151,180,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[0,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar')
    axs[0,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=10)

    #
    #Imagem - 02 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 80
    resolucao_y = 60

    matriz_de_entrada = np.random.randint(0,2,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.8

    coordenada_x2_SRN = 0.2
    coordenada_y2_SRN = 1.0

    #1a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.5

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    #2a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(51,70,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.25

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 1.0

    #3a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(200,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    #4a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.25
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.75

    #5a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.5

    #6a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(121,150,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.8
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.2

    #7a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(151,180,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[0,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar')
    axs[0,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=10)

    #
    #Imagem - 03 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 160
    resolucao_y = 120

    matriz_de_entrada = np.random.randint(0,2,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.8

    coordenada_x2_SRN = 0.2
    coordenada_y2_SRN = 1.0

    #1a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.5

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    #2a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(51,70,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.25

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 1.0

    #3a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(200,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    #4a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.25
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.75

    #5a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.5

    #6a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(121,150,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.8
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.2

    #7a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(151,180,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[0,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar')
    axs[0,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=10)

    #
    #Imagem - 04 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 320
    resolucao_y = 240

    matriz_de_entrada = np.random.randint(0,2,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.8

    coordenada_x2_SRN = 0.2
    coordenada_y2_SRN = 1.0

    #1a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.5

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    #2a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(51,70,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.25

    coordenada_x2_SRN = 0.75
    coordenada_y2_SRN = 1.0

    #3a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(200,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    #4a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.25
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.75

    #5a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.5

    #6a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(121,150,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.8
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.2

    #7a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(151,180,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[0,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar')
    axs[0,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' (QVGA) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=10)

    #
    #Imagem - 05 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 40
    resolucao_y = 30

    matriz_de_entrada = np.random.randint(0,2,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.8

    coordenada_x2_SRN = 0.8
    coordenada_y2_SRN = 1.0

    #1a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.5

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    #2a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(51,70,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.25

    coordenada_x2_SRN = 0.25
    coordenada_y2_SRN = 1.0

    #3a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(200,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 1.0

    #4a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.75
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.75

    #5a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.5

    #6a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(121,150,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.2
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.2

    #7a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(151,180,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[1,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar')
    axs[1,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=10)

    #
    #Imagem - 06 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 80
    resolucao_y = 60

    matriz_de_entrada = np.random.randint(0,2,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.8

    coordenada_x2_SRN = 0.8
    coordenada_y2_SRN = 1.0

    #1a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.5

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    #2a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(51,70,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.25

    coordenada_x2_SRN = 0.25
    coordenada_y2_SRN = 1.0

    #3a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(200,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 1.0

    #4a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.75
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.75

    #5a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.5

    #6a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(121,150,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.2
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.2

    #7a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(151,180,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[1,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar')
    axs[1,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=10)

    #
    #Imagem - 07 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 160
    resolucao_y = 120

    matriz_de_entrada = np.random.randint(0,2,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.8

    coordenada_x2_SRN = 0.8
    coordenada_y2_SRN = 1.0

    #1a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.5

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    #2a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(51,70,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.25

    coordenada_x2_SRN = 0.25
    coordenada_y2_SRN = 1.0

    #3a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(200,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 1.0

    #4a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.75
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.75

    #5a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.5

    #6a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(121,150,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.2
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.2

    #7a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(151,180,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.0

    #reta horizontal na imagem.
    algoritmo_rasterização_de_retas(242,250,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[1,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar')
    axs[1,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=10)

    #
    #Imagem - 08 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 320
    resolucao_y = 240

    matriz_de_entrada = np.random.randint(0,2,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.8

    coordenada_x2_SRN = 0.8
    coordenada_y2_SRN = 1.0

    #1a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.5

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 1.0

    #2a reta diaognal na imagem.
    algoritmo_rasterização_de_retas(51,70,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.25

    coordenada_x2_SRN = 0.25
    coordenada_y2_SRN = 1.0

    #3a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(200,220,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 1.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 1.0

    #4a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.75
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.75

    #5a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(91,120,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.5

    #6a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(121,150,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.2
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 0.0
    coordenada_y2_SRN = 0.2

    #7a reta diagonal na imagem.
    algoritmo_rasterização_de_retas(151,180,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)
    
    axs[1,3].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar')
    axs[1,3].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + '  (QVGA) - ' + str(resolucao_x*resolucao_y) + ' pixels',fontsize=10)

    fig.subplots_adjust(hspace=-0.005, wspace= 0.15)

    plt.show(block=False) 

"""
*******
*
*        -----------------------------------------------------------
*   ~~~ Função "plotagem_de_retas_exemplo_11" implementada pelo aluno ~~~
*        -----------------------------------------------------------
*         - Parâmetros de entrada: Nenhum.
*         - Saída:
*            . Quadro Comparativo mostrando diferentes resoluções entre um ponto qualquer e 
*              retas rasterizadas de tamanho mínimo igual a 1 no SRD.
*
*************************************************************************************************
"""
def plotagem_de_retas_exemplo_11():

    '''
     *
     *     ~Obs. Essa função, como o nome dela mesma já diz kkkk, exibe os resultados obtidos no algoritmo
     *           "algoritmo_rasterização_de_retas" para uma certa entrada de testes.Deixei os nomes das 
     *           variáveis bem 'óbvios' com o intuito de entender as operações condicionais de "if's,
     *           else's,elif's e os while's". Espero que ajudem na compreensão do código kkkkk.
     *           (Qualquer coisa, desculpe qualquer forma de implementação ineficiente ou 'exagerada' rsrsrs)
     *
    '''

    fig, axs = plt.subplots( 3, 3, squeeze=False, figsize = (10,10))

    fig.suptitle('[Quadro Comparativo - Diferentes Resoluções entre um Ponto e Retas Rasterizadas de Tamanho Mínimo(=1)] - No SRD', y=0.99, fontsize=7, fontweight="bold")

    fig.canvas.manager.set_window_title('Diferentes Resoluções entre um Ponto e Retas Rasterizadas de Tamanho Mínimo(=1)')

    gs1 = gridspec.GridSpec(1, 1)

    #
    #Imagem - 01 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 10
    resolucao_y = 10

    matriz_de_entrada = np.random.randint(0,1,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.4

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 0.4

    #Gerando um único ponto no sistema de coordenadsa SRD
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    axs[0,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar') #gist_stern #gist_ncar
    axs[0,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels - '+
                       "Ponto: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+")",fontsize=6)

    #
    #Imagem - 02 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 50
    resolucao_y = 50

    matriz_de_entrada = np.random.randint(0,1,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.4

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 0.4

    #Gerando um único ponto no sistema de coordenadsa SRD
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    axs[0,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar') #gist_stern #gist_ncar
    axs[0,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels - '+
                       "Ponto: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+")",fontsize=6)

    #
    #Imagem - 03 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 150
    resolucao_y = 150

    matriz_de_entrada = np.random.randint(0,1,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.4

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 0.4

    #Gerando um único ponto no sistema de coordenadsa SRD
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    axs[0,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar') #gist_stern #gist_ncar
    axs[0,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels - '+
                       "Ponto: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+")",fontsize=6)

    #
    #Imagem - 04 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 10
    resolucao_y = 10

    matriz_de_entrada = np.random.randint(0,1,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.4

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 0.5

    #reta de distância entre seus 'pontos geradores(que formam a reta com base na distância entre si)' mínima. (Obs. Escolhi 1 como sendo essa 'distância mínima')
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    axs[1,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar') #gist_stern #gist_ncar
    axs[1,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels - '+
                       "Reta: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+") --> ("
                  +str(coordenada_x2_SRN*resolucao_x)+","+str(coordenada_y2_SRN*resolucao_y)+")\nΔx = "+str((coordenada_x2_SRN*resolucao_x)-(coordenada_x1_SRN*resolucao_x))
                  +"  e  Δy = "+str((coordenada_y2_SRN*resolucao_y)-(coordenada_y1_SRN*resolucao_y)),fontsize=6)

    #
    #Imagem - 05 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 50
    resolucao_y = 50

    matriz_de_entrada = np.random.randint(0,1,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.4

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 0.5

    #reta de distância entre seus 'pontos geradores(que formam a reta com base na distância entre si)' mínima. (Obs. Escolhi 1 como sendo essa 'distância mínima')
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    axs[1,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar') #gist_stern #gist_ncar
    axs[1,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels - '+
                       "Reta: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+") --> ("
                  +str(coordenada_x2_SRN*resolucao_x)+","+str(coordenada_y2_SRN*resolucao_y)+")\nΔx = "+str((coordenada_x2_SRN*resolucao_x)-(coordenada_x1_SRN*resolucao_x))
                  +"  e  Δy = "+str((coordenada_y2_SRN*resolucao_y)-(coordenada_y1_SRN*resolucao_y)),fontsize=6)

    #
    #Imagem - 06 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 150
    resolucao_y = 150

    matriz_de_entrada = np.random.randint(0,1,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.4

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 0.5

    #reta de distância entre seus 'pontos geradores(que formam a reta com base na distância entre si)' mínima. (Obs. Escolhi 1 como sendo essa 'distância mínima')
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    axs[1,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar') #gist_stern #gist_ncar
    axs[1,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels - '+
                       "Reta: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+") --> ("
                  +str(coordenada_x2_SRN*resolucao_x)+","+str(coordenada_y2_SRN*resolucao_y)+")\nΔx = "+str((coordenada_x2_SRN*resolucao_x)-(coordenada_x1_SRN*resolucao_x))
                  +"  e  Δy = "+str((coordenada_y2_SRN*resolucao_y)-(coordenada_y1_SRN*resolucao_y)),fontsize=6)

    #
    #Imagem - 07 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 10
    resolucao_y = 10

    matriz_de_entrada = np.random.randint(0,1,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.4

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 0.5

    #1a reta de tamanho "mínimo" na imagem. (Obs. Escolhi 1 como sendo esse 'tamanho mínimo')
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.2
    coordenada_y1_SRN = 0.7

    coordenada_x2_SRN = 0.2
    coordenada_y2_SRN = 0.8

    #2a reta de tamanho "mínimo" na imagem. (Obs. Escolhi 1 como sendo esse 'tamanho mínimo')
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.2
    coordenada_y1_SRN = 0.2

    coordenada_x2_SRN = 0.2
    coordenada_y2_SRN = 0.3

    #3a reta de tamanho "mínimo" na imagem. (Obs. Escolhi 1 como sendo esse 'tamanho mínimo')
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.8
    coordenada_y1_SRN = 0.7

    coordenada_x2_SRN = 0.8
    coordenada_y2_SRN = 0.8

    #4a reta de tamanho "mínimo" na imagem. (Obs. Escolhi 1 como sendo esse 'tamanho mínimo')
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.8
    coordenada_y1_SRN = 0.2

    coordenada_x2_SRN = 0.8
    coordenada_y2_SRN = 0.3

    #5a reta de tamanho "mínimo" na imagem. (Obs. Escolhi 1 como sendo esse 'tamanho mínimo')
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    axs[2,0].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar') #gist_stern #gist_ncar
    axs[2,0].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels - '+
                       "Reta: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+") --> ("
                  +str(coordenada_x2_SRN*resolucao_x)+","+str(coordenada_y2_SRN*resolucao_y)+")\nΔx = "+str((coordenada_x2_SRN*resolucao_x)-(coordenada_x1_SRN*resolucao_x))
                  +"  e  Δy = "+str((coordenada_y2_SRN*resolucao_y)-(coordenada_y1_SRN*resolucao_y)),fontsize=6)

    #
    #Imagem - 08 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 50
    resolucao_y = 50

    matriz_de_entrada = np.random.randint(0,1,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.4

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 0.5

    #1a reta de tamanho "mínimo" na imagem. (Obs. Escolhi 1 como sendo esse 'tamanho mínimo')
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.2
    coordenada_y1_SRN = 0.7

    coordenada_x2_SRN = 0.2
    coordenada_y2_SRN = 0.8

    #2a reta de tamanho "mínimo" na imagem. (Obs. Escolhi 1 como sendo esse 'tamanho mínimo')
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.2
    coordenada_y1_SRN = 0.2

    coordenada_x2_SRN = 0.2
    coordenada_y2_SRN = 0.3

    #3a reta de tamanho "mínimo" na imagem. (Obs. Escolhi 1 como sendo esse 'tamanho mínimo')
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.8
    coordenada_y1_SRN = 0.7

    coordenada_x2_SRN = 0.8
    coordenada_y2_SRN = 0.8

    #4a reta de tamanho "mínimo" na imagem. (Obs. Escolhi 1 como sendo esse 'tamanho mínimo')
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.8
    coordenada_y1_SRN = 0.2

    coordenada_x2_SRN = 0.8
    coordenada_y2_SRN = 0.3

    #5a reta de tamanho "mínimo" na imagem. (Obs. Escolhi 1 como sendo esse 'tamanho mínimo')
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    axs[2,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar') #gist_stern #gist_ncar
    axs[2,1].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels - '+
                       "Reta: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+") --> ("
                  +str(coordenada_x2_SRN*resolucao_x)+","+str(coordenada_y2_SRN*resolucao_y)+")\nΔx = "+str((coordenada_x2_SRN*resolucao_x)-(coordenada_x1_SRN*resolucao_x))
                  +"  e  Δy = "+str((coordenada_y2_SRN*resolucao_y)-(coordenada_y1_SRN*resolucao_y)),fontsize=6)

    #
    #Imagem - 09 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 150
    resolucao_y = 150

    matriz_de_entrada = np.random.randint(0,1,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.5
    coordenada_y1_SRN = 0.4

    coordenada_x2_SRN = 0.5
    coordenada_y2_SRN = 0.5

    #1a reta de tamanho "mínimo" na imagem. (Obs. Escolhi 1 como sendo esse 'tamanho mínimo')
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.2
    coordenada_y1_SRN = 0.7

    coordenada_x2_SRN = 0.2
    coordenada_y2_SRN = 0.8

    #2a reta de tamanho "mínimo" na imagem. (Obs. Escolhi 1 como sendo esse 'tamanho mínimo')
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.2
    coordenada_y1_SRN = 0.2

    coordenada_x2_SRN = 0.2
    coordenada_y2_SRN = 0.3

    #3a reta de tamanho "mínimo" na imagem. (Obs. Escolhi 1 como sendo esse 'tamanho mínimo')
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.8
    coordenada_y1_SRN = 0.7

    coordenada_x2_SRN = 0.8
    coordenada_y2_SRN = 0.8

    #4a reta de tamanho "mínimo" na imagem. (Obs. Escolhi 1 como sendo esse 'tamanho mínimo')
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    coordenada_x1_SRN = 0.8
    coordenada_y1_SRN = 0.2

    coordenada_x2_SRN = 0.8
    coordenada_y2_SRN = 0.3

    #5a reta de tamanho "mínimo" na imagem. (Obs. Escolhi 1 como sendo esse 'tamanho mínimo')
    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    axs[2,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar') #gist_stern #gist_ncar
    axs[2,2].set_title('Resolução ' + str(resolucao_x) + ' x ' + str(resolucao_y) + ' - ' + str(resolucao_x*resolucao_y) + ' pixels - '+
                       "Reta: ("+str(coordenada_x1_SRN*resolucao_x)+","+str(coordenada_y1_SRN*resolucao_y)+") --> ("
                  +str(coordenada_x2_SRN*resolucao_x)+","+str(coordenada_y2_SRN*resolucao_y)+")\nΔx = "+str((coordenada_x2_SRN*resolucao_x)-(coordenada_x1_SRN*resolucao_x))
                  +"  e  Δy = "+str((coordenada_y2_SRN*resolucao_y)-(coordenada_y1_SRN*resolucao_y)),fontsize=6)

    fig.subplots_adjust(hspace=0.38, wspace= 0.15)

    plt.show(block=False) 

"""
*******
*
*        -----------------------------------------------------------
*   ~~~ Função "plotagem_explicativa" implementada pelo aluno ~~~
*        -----------------------------------------------------------
*         - Parâmetros de entrada: Nenhum.
*         - Saída:
*            . Figura explicativa sobre a transformação de uma reta no SRN para uma reta 
*              "Rasterizada" no SRD.
*
*************************************************************************************************
"""
def plotagem_explicativa():

    '''
     *
     *     ~Obs. Essa função, eu coloquei como um "bônus mesmo" só para exibir esse processo de conversão "SRN-->SRD".
     *           (Qualquer coisa, desculpe qualquer forma de implementação ineficiente ou 'exagerada' rsrsrs)
     *
    '''

    fig, axs = plt.subplots( 2, 3, squeeze=False, figsize = (10,10))

    fig.suptitle('[Figura Explicativa - Transformação de Reta no SRN para uma Reta "Rasterizada" no SRD]', y=0.97, fontsize=8, fontweight="bold")

    fig.canvas.manager.set_window_title('Transformação de Reta no SRN para uma Reta "Rasterizada" no SRD')

    gs1 = gridspec.GridSpec(1, 1)

    #
    #Imagem - 01 - //////////////////////////////////////////////////////////:
    #

    x = [0.0,1.0]
    y = [0.0,1.0]
    
    axs[0,0].plot(x, y, color="lime", linewidth=1)
    axs[0,0].set_facecolor("navy")

    axs[0,0].set_xlim([0.0, 1.0])
    axs[0,0].set_ylim([0.0, 1.0])

    axs[0,0].set_title('Exemplo 01 - Reta no "Sistema de Referência Normalizado" (SRN)\n (Para: 0.0 ≤ x,y ≤ 1.0)',fontsize=6)

    #
    #Imagem - 02 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 10
    resolucao_y = 10

    matriz_de_entrada = np.random.randint(0,1,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    x = [0,10]
    y = [0,10]
    
    axs[0,1].plot(x, y, color="lime", linewidth=2)

    axs[0,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar') 
    axs[0,1].set_title('Processo de "Rasterização" da Reta do Exemplo 01, do SRN para o SRD na resolução 10x10\n (É o que o algoritmo aqui implementado pelo aluno busca fazer!)',fontsize=6)

    #
    #Imagem - 03 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 10
    resolucao_y = 10

    matriz_de_entrada = np.random.randint(0,1,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 1.0

    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    axs[0,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar') 
    axs[0,2].set_title('Reta "Rasterizada" no "Sistema de Referência do Dispositivo" (SRD) - Resolução 10x10\n(Apartir da Reta do Exemplo 01 e suas coordenadas no SRN)',fontsize=6)

    #
    #Imagem - 04 - //////////////////////////////////////////////////////////:
    #

    x = [0.0,1.0]
    y = [0.0,0.5]
    
    axs[1,0].plot(x, y, color="lime", linewidth=1)
    axs[1,0].set_facecolor("navy")

    axs[1,0].set_xlim([0.0, 1.0])
    axs[1,0].set_ylim([0.0, 1.0])

    axs[1,0].set_title('Exemplo 02 - Reta no "Sistema de Referência Normalizado" (SRN)\n (Para: 0.0 ≤ x,y ≤ 1.0)',fontsize=6)

    #
    #Imagem - 05 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 10
    resolucao_y = 10

    matriz_de_entrada = np.random.randint(0,1,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.5

    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    x = [0,10]
    y = [0,5]
    
    axs[1,1].plot(x, y, color="lime", linewidth=2)

    axs[1,1].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar') 
    axs[1,1].set_title('Processo de "Rasterização" da Reta do Exemplo 02, do SRN para o SRD na resolução 10x10\n (É o que o algoritmo aqui implementado pelo aluno busca fazer!)',fontsize=6)

    #
    #Imagem - 06 - //////////////////////////////////////////////////////////:
    #

    resolucao_x = 10
    resolucao_y = 10

    matriz_de_entrada = np.random.randint(0,1,(resolucao_y,resolucao_x)) 

    coordenada_x1_SRN = 0.0
    coordenada_y1_SRN = 0.0

    coordenada_x2_SRN = 1.0
    coordenada_y2_SRN = 0.5

    algoritmo_rasterização_de_retas(20,40,matriz_de_entrada,resolucao_x,resolucao_y,coordenada_x1_SRN,coordenada_y1_SRN,coordenada_x2_SRN,coordenada_y2_SRN)

    axs[1,2].imshow(matriz_de_entrada, interpolation='nearest', aspect='equal', origin='lower', cmap='gist_ncar') 
    axs[1,2].set_title('Reta "Rasterizada" no "Sistema de Referência do Dispositivo" (SRD) - Resolução 10x10\n(Apartir da Reta do Exemplo 02 e suas coordenadas no SRN)',fontsize=6)

    fig.subplots_adjust(hspace=0.5, wspace= 0.6)

    plt.show(block=False) 

"""
*
*       ******************************************************
*  ~~~ Construção de Interface Gráfica com a biblioteca Tkinter ~~~
*       ******************************************************
*
"""

# Cria objeto "Tkinter"/"Tk"
root = Tk()

# Muda o ícone padrão da janela do Tkinter
icone_asset_url = resource_path('recursos/icone.ico')
root.iconbitmap(icone_asset_url)
  
# Ajusta geometria "padrão" da janela da interface criada no Tkinter
root.geometry("560x619")

# Altera o título da janela da interface criada no Tkinter
root.title("Trabalho 1: rasterização de retas - João Gabriel")
  
# Adicona Imagem como plano de fundo da janela da interface criada no Tkinter
bg_asset_url = resource_path('recursos/img_de_fundo.png')
bg = PhotoImage(file = bg_asset_url)
  
# Label que mostra a imagem de plano de fundo da janela
label1 = Label( root, image = bg)
label1.place(x = 0, y = 0)#posicionado na posição (0,0) da janela

# Label que exibe os textos dos botões na janela
label2 = Label(root,text = "*Passe o mouse em cima de um\nbotão ao lado para saber que tipo\nde retas serão exibidas na imagem\nplotada!",bg = "white",fg = "red",anchor="e", justify=LEFT)
label2.place(x = 319, y = 511)

# Funções chamadas pelos botões 1 ao 11, responsáveis por mudar o texto do "label2"
def muda_texto_explica_botao_01(event):
    label2.config(text="*Diferentes Resoluções e Tempos de\nComputação de Reta Rasterizada\nno SRD com: Δx > Δy.")

def muda_texto_explica_botao_02(event):
    label2.config(text="Diferentes Resoluções e Tempos de\nComputação de Reta Rasterizada\nno SRD com: Δy > Δx.")

def muda_texto_explica_botao_03(event):
    label2.config(text="Diferentes Resoluções e Tempos de\nComputação de Reta Rasterizada\nno SRD com: Δy = Δx.")

def muda_texto_explica_botao_04(event):
    label2.config(text="Diferentes Resoluções e Tempos de\nComputação de Reta Rasterizada\nno SRD com: Δx = 0.")

def muda_texto_explica_botao_05(event):
    label2.config(text="Diferentes Resoluções e Tempos de\nComputação de Reta Rasterizada\nno SRD com: Δy = 0.")

def muda_texto_explica_botao_06(event):
    label2.config(text="Diferentes Resoluções de Retas\nRasterizadas no SRD com:\n(Δy ou Δx) = 0 e Próximas as\nBordas do Plano X ou Y.")

def muda_texto_explica_botao_07(event):
    label2.config(text="Diferentes Resoluções de Diferentes\n Retas Rasterizadas no SRD\n com: (Δy ou Δx) = 0.")

def muda_texto_explica_botao_08(event):
    label2.config(text="Diferentes Retas Rasterizadas\n no SRD com Origem nas\n Coordenadas: (0.0,0.0) ou (1.0,1.0)\n - Exemplo 01.")

def muda_texto_explica_botao_09(event):
    label2.config(text="Diferentes Retas Rasterizadas\n no SRD com Origem nas\n Coordenadas: (1.0,0.0) ou (0.0,1.0)\n - Exemplo 02.")

def muda_texto_explica_botao_10(event):
    label2.config(text="Diferentes Resoluções de Múltiplas\n Retas Diagonais Rasterizadas\n no SRD.")

def muda_texto_explica_botao_11(event):
    label2.config(text="Diferentes Resoluções entre um\n Ponto e Retas Rasterizadas\n de Tamanho Mínimo(=1) no SRD.")

# Define tamanho da fonte
myFont = font.Font(size=8)
  
# Adiciona 1 botão a janela:
#
#*   .1- O parâmetro 'bg = "#b8a7be"' muda a cor do botão para uma em HEX.
#*   .2- O parâmetro 'bcommand=plotagem_de_retas_exemplo_01' associa uma função ao botão quando este for clicado.
#####
button1 = Button(root,text = "  Imagem 01  ",bg = "#b8a7be",command=plotagem_de_retas_exemplo_01)

# Aplica tamanho da fonte ao botão
button1['font'] = myFont

# Posiciona botão na janela
button1.place(x=29, y=508)

# Define função ao botão que "muda o texto do label2" caso o cursor do mouse passe por cima da área do botão
button1.bind("<Enter>", muda_texto_explica_botao_01)

# Criando e ajustando os outros botões da interface gráfica
button2 = Button(root,text = "  Imagem 02  ",bg = "#b8a7be",command=plotagem_de_retas_exemplo_02)
button2['font'] = myFont
button2.place(x=103, y=508)
button2.bind("<Enter>", muda_texto_explica_botao_02)

button3 = Button(root,text = "  Imagem 03  ",bg = "#b8a7be",command=plotagem_de_retas_exemplo_03)
button3['font'] = myFont
button3.place(x=177, y=508)
button3.bind("<Enter>", muda_texto_explica_botao_03)

button4 = Button(root,text = "  Imagem 04  ",bg = "#b8a7be",command=plotagem_de_retas_exemplo_04)
button4['font'] = myFont
button4.place(x=29, y=535)
button4.bind("<Enter>", muda_texto_explica_botao_04)

button5 = Button(root,text = "  Imagem 05  ",bg = "#b8a7be",command=plotagem_de_retas_exemplo_05)
button5['font'] = myFont
button5.place(x=103, y=535)
button5.bind("<Enter>", muda_texto_explica_botao_05)

button6 = Button(root,text = "  Imagem 06  ",bg = "#b8a7be",command=plotagem_de_retas_exemplo_06)
button6['font'] = myFont
button6.place(x=177, y=535)
button6.bind("<Enter>", muda_texto_explica_botao_06)

button7 = Button(root,text = "  Imagem 07  ",bg = "#b8a7be",command=plotagem_de_retas_exemplo_07)
button7['font'] = myFont
button7.place(x=29, y=562)
button7.bind("<Enter>", muda_texto_explica_botao_07)

button8 = Button(root,text = "  Imagem 08  ",bg = "#b8a7be",command=plotagem_de_retas_exemplo_08)
button8['font'] = myFont
button8.place(x=103, y=562)
button8.bind("<Enter>", muda_texto_explica_botao_08)

button9 = Button(root,text = "  Imagem 09  ",bg = "#b8a7be",command=plotagem_de_retas_exemplo_09)
button9['font'] = myFont
button9.place(x=177, y=562)
button9.bind("<Enter>", muda_texto_explica_botao_09)

button10 = Button(root,text = "  Imagem 10  ",bg = "#b8a7be",command=plotagem_de_retas_exemplo_10)
button10['font'] = myFont
button10.place(x=29, y=589)
button10.bind("<Enter>", muda_texto_explica_botao_10)

button11 = Button(root,text = "  Imagem 11  ",bg = "#b8a7be",command=plotagem_de_retas_exemplo_11)
button11['font'] = myFont
button11.place(x=103, y=589)
button11.bind("<Enter>", muda_texto_explica_botao_11)

button_Duvidas = Button(root,text = "  ?  ",bg = "#f0ebf8",command=plotagem_explicativa)
button_Duvidas['font'] = myFont
button_Duvidas.place(x=489, y=126)

# Executa o Tkinter
root.mainloop()
