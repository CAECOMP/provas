"""
*
********************************************************************************************************************************
* Trabalho_02_Joao_Gabriel_Gustavo_Vasconcelos.py 03/07/2021                                                                   *
*                                                                                                                              *
*   ( )[][]                                                                                                                    *
*   [][]                                                                                                                       *
*   [][][]                                                                                                                     *
*   [][]   - Computação Gráfica - 2021.1 - Prof.Ajalmar                                                                        *
*                                                                                                                              *
* Copyright 2021 - João Gabriel Carneiro Medeiros & Gustavo Vasconcelos,                                                       *                                                                                                                            
* Instituto Federal de Educação, Ciência e Tecnologia do Ceará - IFCE                                                          *
* Todos os direitos reservados                                                                                                 *
**************************************************************************************************************************************************
*                                                                                                                                                *
*  !!!ATENÇÃO!!! - É preferível que o código seja executado no Windows(de preferência o Windows 10)!                                             * 
*                                                                                                                                                *
*  !!!ATENÇÃO!!! - Esse programa só pode rodar de forma apropriada entra quaisquer versões do Python que estejam entre:                          * 
*                  'Python 3.5x-3.7x'. Eu mesmo rodei e fiz o código na versão 'Python 3.7.9 '. Caso queira, aqui o link para                    *
*                  baixar a veersão 'Python 3.7.9 ': https://www.python.org/downloads/release/python-379/                                        *
*                  (Porque isso é necessário? Veja a seguinte discussão para saber o motivo:                                                     *
*                   https://stackoverflow.com/questions/62204687/python-installing-old-version-of-matplotlib-results-in-freetype-and-png-error)  *
*                                                                                                                                                * 
*       Obs.     - Após baixar a versão 'Python 3.7.9 ' no seu PC, se ele for Windows (de preferência o Windows 10) abra seu                     *
*                  'Prompt de comando' e execute o comando: 'pip3 install matplotlib==3.0.3'. Pronto, agora você poderá 'rodar'                  *
*                  esse código sem problemas.                                                                                                    *
*                                                                                                                                                *
**************************************************************************************************************************************************
*
"""

"""
*
*       *******************
*  ~~~ Bibliotecas utilizada ~~~
*       *******************
*
"""

# Usam-se essas duas bibliotecas abaixo para se criar o arquivo '.EXE' que foi mandado.
import sys
import os

# Bibliotecas usadas para criar e realizar operações com as matrizes usadas ao longo do código (torna algumas inicializações e cálculos mais ''fáceis'' kkkk).
import math
import numpy as np

# Usam-se das duas bibliotecas abaixo para a ''plotagem'' ou ''exibição'' das imagens pedidas no trabalho.
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from mpl_toolkits.mplot3d import Axes3D
from mpl_toolkits.mplot3d.art3d import Poly3DCollection, Line3DCollection

# Biblioteca Tkinter usada para a criação da interface gráfica que o trabalho da equipe apresenta.
from tkinter import *
import tkinter.font as font

# Biblioteca usada para possibilitar vincular um link de uma página a um botão da biblioteca Tkinter.
import webbrowser

"""
*
*       ******************************************************
*  ~~~ Funções Auxiliares para algumas 'funcionalidades extras' ~~~
*       v*****************************************************
*
"""

# Usa-se dessa função para manipular as imagens e outros arquivos que são usados como recursos gráficos no código para poder criar o '.EXE' do mesmo (Como uma "compactação na hora de criar o arquivo").
def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)

# Função usada para criar os "Hyperlinks" que existem nos botões das janelas abertas após clicar nos botões com ícone "@?" da janela principal da interface.
def callback(url):
    webbrowser.open_new(url)

"""
*
*       ************************************************************************************
*  ~~~ Funções que mexem com o Matplotlib e 'plotam' as imagens vistas nos gráficos mostrados ~~~
*       ************************************************************************************
*
"""

# Função que "plota" o gráfico em 3D do ícone do IFCE, o professor já viu esse código antes, talves, numa atividade que passou kkkk, usamos de novo porque é legal rsrsrs.
def plota_IF_3d(matrizes,colors,alphas):
  
  fig = plt.figure(figsize=(8, 8))
  
  ax = fig.add_subplot(111, projection='3d')
  
  r = [-1,1]
  X, Y = np.meshgrid(r, r)

  fig.canvas.manager.set_window_title('IFCE - Eng. Computação - Computação Gráfica - Prof. Ajalmar Rego')
  
  for i in range(len(matrizes)):

    if i == 0:
      ax.scatter3D(matrizes[i][:, 0], matrizes[i][:, 1], matrizes[i][:, 2], color='red')
    else:
      ax.scatter3D(matrizes[i][:, 0], matrizes[i][:, 1], matrizes[i][:, 2], color='green')
    
    vertices_cubo = [[matrizes[i][0],matrizes[i][1],matrizes[i][2],matrizes[i][3]],
              [matrizes[i][4],matrizes[i][5],matrizes[i][6],matrizes[i][7]], 
              [matrizes[i][0],matrizes[i][1],matrizes[i][5],matrizes[i][4]], 
              [matrizes[i][2],matrizes[i][3],matrizes[i][7],matrizes[i][6]], 
              [matrizes[i][1],matrizes[i][2],matrizes[i][6],matrizes[i][5]],
              [matrizes[i][4],matrizes[i][7],matrizes[i][3],matrizes[i][0]]]

    if i == 0:
      poly3Dcol = Poly3DCollection(vertices_cubo, linewidths=1, linestyle='dashed', edgecolors=colors[i])
    else:
      poly3Dcol = Poly3DCollection(vertices_cubo, linewidths=1, edgecolors=colors[i])
      
    poly3Dcol.set_alpha(alphas[i])
    poly3Dcol.set_facecolor(colors[i])

    ax.add_collection3d(poly3Dcol)
    
  
  ax.set_zlim3d(0,7.5)
  ax.set_xlim3d(0,7.5)
  ax.set_ylim3d(0,7.5)
  ax.set_xlabel(' \n\n\n X \n\n IFCE - Instituto Federal de Educação, Ciência e Tecnologia do Ceará \n Eng. Computação - Computação Gráfica ')
  ax.set_ylabel('Y')
  ax.set_zlabel('Z')

  # Essa linha de código já foi usada no trabalho passado pelo aluno João Gabriel, isso permite ao matplotlib 'plottar' em mais de uma janela separadamente, por isso
  # 2 janelas ou mais podem surgir durante a execuçãor do código ao se clicar nos botões que geram essas janelas, aqui a equipe está usadno de novo dessa "ajuda".
  plt.show(block=False)

# Função que "constrói" a figura geométrica do símbolo do IFCE e suas coordenadas em 3D e usa da função "plota_IF_3d" acima para criar a janela com o símbolo do IFCE em 3D.
def cria_IF_3d(event):
  
  # IFCE - Logo - Na vertical
  
  peca_IF_01 = np.array([[2, 3, 3.75],  
                   [3, 3, 3.75],
                   [3, 3, 4.75],
                   [2, 3, 4.75],
                   [2, 4, 3.75],
                   [3, 4, 3.75],
                   [3, 4, 4.75],
                   [2, 4, 4.75]])

  peca_IF_02 = np.array([[2, 3, 1.25],  
                   [3, 3, 1.25],
                   [3, 3, 2.25],
                   [2, 3, 2.25],
                   [2, 4, 1.25],
                   [3, 4, 1.25],
                   [3, 4, 2.25],
                   [2, 4, 2.25]])

  peca_IF_03 = np.array([[2, 3, 2.5],  
                   [3, 3, 2.5],
                   [3, 3, 3.5],
                   [2, 3, 3.5],
                   [2, 4, 2.5],
                   [3, 4, 2.5],
                   [3, 4, 3.5],
                   [2, 4, 3.5]])

  peca_IF_04 = np.array([[2, 3, 0],
                   [3, 3, 0],
                   [3, 4, 0],
                   [2, 4, 0],
                   [2, 3, 1],
                   [3, 3, 1],
                   [3, 4, 1],
                   [2, 4, 1]])

  peca_IF_05 = np.array([[3.25, 3, 1.25],
                   [4.25, 3, 1.25],
                   [4.25, 4, 1.25],
                   [3.25, 4, 1.25],
                   [3.25, 3, 2.25],
                   [4.25, 3, 2.25],
                   [4.25, 4, 2.25],
                   [3.25, 4, 2.25]])

  peca_IF_06 = np.array([[3.25, 3, 0],
                   [4.25, 3, 0],
                   [4.25, 4, 0],
                   [3.25, 4, 0],
                   [3.25, 3, 1],
                   [4.25, 3, 1],
                   [4.25, 4, 1],
                   [3.25, 4, 1]])

  peca_IF_07 = np.array([[4.5, 3, 1.25],  
                   [5.5, 3, 1.25],
                   [5.5, 3, 2.25],
                   [4.5, 3, 2.25],
                   [4.5, 4, 1.25],
                   [5.5, 4, 1.25],
                   [5.5, 4, 2.25],
                   [4.5, 4, 2.25]])

  peca_IF_08 = np.array([[3.25, 3, 2.5],  
                   [4.25, 3, 2.5],
                   [4.25, 3, 3.5],
                   [3.25, 3, 3.5],
                   [3.25, 4, 2.5],
                   [4.25, 4, 2.5],
                   [4.25, 4, 3.5],
                   [3.25, 4, 3.5]])

  peca_IF_09 = np.array([[3.25, 3, 3.75],
                   [4.25, 3, 3.75],
                   [4.25, 3, 4.75],
                   [3.25, 3, 4.75],
                   [3.25, 4, 3.75],
                   [4.25, 4, 3.75],
                   [4.25, 4, 4.75],
                   [3.25, 4, 4.75]])

  peca_IF_10 = np.array([[4.5, 3, 3.75],
                   [5.5, 3, 3.75],
                   [5.5, 3, 4.75],
                   [4.5, 3, 4.75],
                   [4.5, 4, 3.75],
                   [5.5, 4, 3.75],
                   [5.5, 4, 4.75],
                   [4.5, 4, 4.75]])

  cores = ['red','g','g','g','g','g','g','g','g','g']
  alphas = [0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1,0.1]
  matrizes_de_entrada = [peca_IF_01,peca_IF_02,peca_IF_03,peca_IF_04,peca_IF_05,peca_IF_06,peca_IF_07,peca_IF_08,peca_IF_09,peca_IF_10]
  plota_IF_3d(matrizes_de_entrada,cores,alphas)

'''
Vertices e matrizes de transformações dos sólidos
'''

vertices_cubo = np.array([[0, 0, 0],
                          [1, 0, 0],
                          [1, 1, 0],
                          [0, 1, 0],
                          [0, 0, 1],
                          [1, 0, 1],
                          [1, 1, 1],
                          [0, 1, 1]])
transformacao_cubo = [[1.5, 0, 0],
                      [0, 1.5, 0],
                      [0, 0, 1.5]]
translacao_cubo = (-3.5, -3.5, 0)


vertices_retangulo = np.array([[0, 0, 0],
                               [1, 0, 0],
                               [1, 1, 0],
                               [0, 1, 0],
                               [0, 0, 1],
                               [1, 0, 1],
                               [1, 1, 1],
                               [0, 1, 1]])
transformacao_retangulo = [[1.5, 0, 0],
                           [0, 5, 0],
                           [0, 0, 2.5]]
translacao_retangulo = (0.5/1.5, -1.1, 0)


vertices_piramide = np.array([[2, 0, 0],
                              [0, 2, 0],
                              [-2, 0, 0],
                              [0, -2, 0],
                              [0, 0, 3]])
transformacao_piramide = [[1, 0, 0],
                          [0, 1, 0],
                          [0, 0, 1]]
translacao_piramide = (-2.5, -2.5, 0)


vertices_tronco = np.array([[0, 0, 0],
                            [3, 0, 0],
                            [3, 3, 0],
                            [0, 3, 0],
                            [0.85, 0.85, 2.5],
                            [2.15, 0.85, 2.5],
                            [2.15, 2.15, 2.5],
                            [0.85, 2.15, 2.5]])
transformacao_tronco = [[1, 0, 0],
                        [0, 1, 0],
                        [0, 0, 1]]
translacao_tronco = (2.5, -3.5, 0)


transformacao_nula = [[1, 0, 0],
                      [0, 1, 0],
                      [0, 0, 1]]
translacao_nula = (0, 0, 0)

'''

Funções Variadas para o auxílio dos cálculos feitos:

'''

#Plot de cubo, retangulo e tronco
def PlotaSolido1(pontos, m_translacao, m_transformacao, cor_pontos, cor_faces, cor_arestas,ax):
    
    pontos = pontos + m_translacao
    pontos = np.dot(pontos, m_transformacao)
    arestas = [[pontos[0],pontos[1],pontos[2],pontos[3]],
               [pontos[4],pontos[5],pontos[6],pontos[7]],
               [pontos[0],pontos[1],pontos[5],pontos[4]],
               [pontos[2],pontos[3],pontos[7],pontos[6]],
               [pontos[1],pontos[2],pontos[6],pontos[5]],
               [pontos[4],pontos[7],pontos[3],pontos[0]]]

    ax.add_collection3d(Poly3DCollection(arestas, facecolors=cor_faces, linewidths=1,
                                         edgecolors=cor_arestas, alpha=.25))
    
    return pontos

#Plot de piramide
def PlotaSolido2(pontos, m_translacao, m_transformacao, cor_pontos, cor_faces, cor_arestas,ax):
    pontos = pontos + m_translacao
    pontos = np.dot(pontos, m_transformacao)
    arestas = [[pontos[0],pontos[1],pontos[2],pontos[3]],
               [pontos[0],pontos[1],pontos[4]],
               [pontos[1],pontos[2],pontos[4]],
               [pontos[2],pontos[3],pontos[4]],
               [pontos[3],pontos[0],pontos[4]]]

    ax.add_collection3d(Poly3DCollection(arestas, facecolors=cor_faces, linewidths=1,
                                         edgecolors=cor_arestas, alpha=.25))

    return pontos

def PontoMedio(vertices):
    medio = np.mean(vertices, axis=0)
    return medio

def PlotaPonto(point, color,ax):
    ax.scatter3D(point[0], point[1], point[2], color=color)

def PlotaAresta(point1, point2, cor,ax):
    aresta = ([point1, point2])
    ax.add_collection3d(Poly3DCollection(aresta, facecolors='black', linewidths=1,
                                     edgecolors=cor, alpha=0.25))

def Multiplica3x4(matriz3, matriz4):
    matriz3 = np.hstack((matriz3, np.ones((len(matriz3), 1))))
    matriz3 = np.dot(matriz3, matriz4)
    matriz3 = np.delete(matriz3, 3, axis=1)
    return matriz3

def MundoParaCamera(pontos, m_translacao, m_transformacao, RT):
    pontos = pontos + m_translacao
    pontos = np.dot(pontos, m_transformacao)
    pontos = Multiplica3x4(pontos, RT)
    return pontos

def ProjecaoOrtogonal(pontos, transformacao_2d):
    pontos = Multiplica3x4(pontos, transformacao_2d)
    pontos = np.delete(pontos, 2, axis=1)
    return pontos

'''

Questão 1

'''

def Questao1_plota_somente_CUBO():

    #Inicialização do plot

    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    fig.canvas.manager.set_window_title('Trabalho 02 - N2 - CG  - Item 01 - Imagens')

    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')

    r = [-1,1]
    X, Y = np.meshgrid(r, r)

    '''
    Configurações finais do plot
    '''
    #Eixos
    PlotaAresta([[6, 0, 0]], [[-6, 0, 0]], 'black',ax)
    PlotaAresta([[0, 6, 0]], [[0, -6, 0]], 'black',ax)
    PlotaAresta([[0, 0, 6]], [[0, 0, -6]], 'black',ax)

    #Limite dos plots
    axes = plt.gca()
    axes.set_xlim([-6, 6])
    axes.set_ylim([-6, 6])
    axes.set_zlim([-6, 6])

    
    PlotaSolido1(vertices_cubo, translacao_nula, transformacao_cubo, 'green', 'green', 'g',ax)

    #plt.figure(index_janela)
    plt.title("Plot - Cubo do Item 01 - Forma Geométrica Isolada num Sistema de Coordenadas 3D")
    plt.show(block=False)

def Questao1_plota_somente_RETANGULO():

    #Inicialização do plot

    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    fig.canvas.manager.set_window_title('Trabalho 02 - N2 - CG  - Item 01 - Imagens')

    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')

    r = [-1,1]
    X, Y = np.meshgrid(r, r)

    '''
    Configurações finais do plot
    '''
    #Eixos
    PlotaAresta([[6, 0, 0]], [[-6, 0, 0]], 'black',ax)
    PlotaAresta([[0, 6, 0]], [[0, -6, 0]], 'black',ax)
    PlotaAresta([[0, 0, 6]], [[0, 0, -6]], 'black',ax)

    #Limite dos plots
    axes = plt.gca()
    axes.set_xlim([-6, 6])
    axes.set_ylim([-6, 6])
    axes.set_zlim([-6, 6])
    
    PlotaSolido1(vertices_retangulo, translacao_nula, transformacao_retangulo, 'red', 'red', 'r',ax)

    #plt.figure()
    plt.title("Plot - Retângulo do Item 01 - Forma Geométrica Isolada num Sistema de Coordenadas 3D")
    plt.show(block=False)

def Questao1_plota_somente_PIRAMIDE():

    #Inicialização do plot

    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    fig.canvas.manager.set_window_title('Trabalho 02 - N2 - CG  - Item 01 - Imagens')

    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')

    r = [-1,1]
    X, Y = np.meshgrid(r, r)

    '''
    Configurações finais do plot
    '''
    #Eixos
    PlotaAresta([[6, 0, 0]], [[-6, 0, 0]], 'black',ax)
    PlotaAresta([[0, 6, 0]], [[0, -6, 0]], 'black',ax)
    PlotaAresta([[0, 0, 6]], [[0, 0, -6]], 'black',ax)

    #Limite dos plots
    axes = plt.gca()
    axes.set_xlim([-6, 6])
    axes.set_ylim([-6, 6])
    axes.set_zlim([-6, 6])
    
    PlotaSolido2(vertices_piramide, translacao_nula, transformacao_piramide, 'green', 'green', 'g',ax)

    plt.title("Plot - Pirâmide do Item 01 - Forma Geométrica Isolada num Sistema de Coordenadas 3D")
    plt.show(block=False)

def Questao1_plota_somente_TRONCO():

    #Inicialização do plot

    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    fig.canvas.manager.set_window_title('Trabalho 02 - N2 - CG  - Item 01 - Imagens')

    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')

    r = [-1,1]
    X, Y = np.meshgrid(r, r)

    '''
    Configurações finais do plot
    '''
    #Eixos
    PlotaAresta([[6, 0, 0]], [[-6, 0, 0]], 'black',ax)
    PlotaAresta([[0, 6, 0]], [[0, -6, 0]], 'black',ax)
    PlotaAresta([[0, 0, 6]], [[0, 0, -6]], 'black',ax)

    #Limite dos plots
    axes = plt.gca()
    axes.set_xlim([-6, 6])
    axes.set_ylim([-6, 6])
    axes.set_zlim([-6, 6])
    
    PlotaSolido1(vertices_tronco, translacao_nula, transformacao_tronco, 'red', 'red', 'r',ax)

    plt.title("Plot - Tronco de Pirâmide do Item 01 - Forma Geométrica Isolada num Sistema de Coordenadas 3D")
    plt.show(block=False)

def Questao1_plota_todas_as_figuras():

    #Inicialização do plot

    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    fig.canvas.manager.set_window_title('Trabalho 02 - N2 - CG  - Item 01 - Imagens')

    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')

    r = [-1,1]
    X, Y = np.meshgrid(r, r)

    '''
    Configurações finais do plot
    '''
    #Eixos
    PlotaAresta([[6, 0, 0]], [[-6, 0, 0]], 'black',ax)
    PlotaAresta([[0, 6, 0]], [[0, -6, 0]], 'black',ax)
    PlotaAresta([[0, 0, 6]], [[0, 0, -6]], 'black',ax)

    #Limite dos plots
    axes = plt.gca()
    axes.set_xlim([-6, 6])
    axes.set_ylim([-6, 6])
    axes.set_zlim([-6, 6])

    # Escolhemos ser preto aqui só pra num ficar uma "tempestade de cores" kkkkk.
    PlotaSolido1(vertices_cubo, translacao_nula, transformacao_cubo, 'black', 'black', 'k',ax)
    PlotaSolido1(vertices_retangulo, translacao_nula, transformacao_retangulo, 'black', 'black', 'k',ax)    
    PlotaSolido2(vertices_piramide, translacao_nula, transformacao_piramide, 'black', 'black', 'k',ax)    
    PlotaSolido1(vertices_tronco, translacao_nula, transformacao_tronco, 'black', 'black', 'k',ax)

    plt.title("Plot - Formas Geométricas do Item 01 - Em um mesmo Sistema de Coordenadas 3D")
    plt.show(block=False)

'''

Questões 2 e 3

'''


#Cálculo do centro de massa

t1 = vertices_cubo + translacao_cubo
t1 = np.dot(t1, transformacao_cubo)
t1 = PontoMedio(t1)

t2 = vertices_piramide + translacao_piramide
t2 = np.dot(t2, transformacao_piramide)
t2 = PontoMedio(t2)

centro_massa = (t1 + t2) / 2


#Cálculo das coordenadas da câmera


aux = (2, -2, -2)
eye = (3, 3, -1)
at = centro_massa

vet_n = np.subtract(at, eye)
vet_n = (vet_n / np.linalg.norm(vet_n))
aux = (aux / np.linalg.norm(aux))
vet_v = np.cross(vet_n, aux)
vet_v = (vet_v / np.linalg.norm(vet_v))
vet_u = np.cross(vet_v, vet_n)
vet_u = (vet_u / np.linalg.norm(vet_u))



#Transformação das coordenadas do Mundo para Câmera

RT = np.array([[vet_u[0], vet_u[1], vet_u[2], -(eye[0]*vet_u[0])-(eye[1]*vet_u[1])-(eye[2]*vet_u[2])],
               [vet_v[0], vet_v[1], vet_v[2], -(eye[0]*vet_v[0])-(eye[1]*vet_v[1])-(eye[2]*vet_v[2])],
               [vet_n[0], vet_n[1], vet_n[2], -(eye[0]*vet_n[0])-(eye[1]*vet_n[1])-(eye[2]*vet_n[2])],
               [0, 0, 0, 1]])

new_cubo = MundoParaCamera(vertices_cubo, translacao_cubo, transformacao_cubo, RT)
new_piramide = MundoParaCamera(vertices_piramide, translacao_piramide, transformacao_piramide, RT)


#Funções para plotar tudo das Questões 2 e 3

def plota_Questao2(vertices_cubo, translacao_cubo, transformacao_cubo,
               vertices_retangulo, translacao_retangulo, transformacao_retangulo,
               vertices_piramide, translacao_piramide, transformacao_piramide,
               vertices_tronco, translacao_tronco, transformacao_tronco):

    #Inicialização do plot

    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    fig.canvas.manager.set_window_title('Trabalho 02 - N2 - CG  - Item 02 - Apresentação dos Diversos Sólidos no Sistema de Coord. 3D')

    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')

    r = [-1,1]
    X, Y = np.meshgrid(r, r)

    #Eixos
    PlotaAresta([[6, 0, 0]], [[-6, 0, 0]], 'black',ax)
    PlotaAresta([[0, 6, 0]], [[0, -6, 0]], 'black',ax)
    PlotaAresta([[0, 0, 6]], [[0, 0, -6]], 'black',ax)

    #Limite dos plots
    axes = plt.gca()
    axes.set_xlim([-6, 6])
    axes.set_ylim([-6, 6])
    axes.set_zlim([-6, 6])

    PlotaSolido1(vertices_cubo, translacao_cubo, transformacao_cubo, 'green', 'green', 'g',ax)
    PlotaSolido1(vertices_retangulo, translacao_retangulo, transformacao_retangulo, 'red', 'red', 'r',ax)
    PlotaSolido2(vertices_piramide, translacao_piramide, transformacao_piramide, 'green', 'green', 'g',ax)
    PlotaSolido1(vertices_tronco, translacao_tronco, transformacao_tronco, 'red', 'red', 'r',ax)

    plt.title("Plot - Formas Geométricas do Item 02 - Em um mesmo Sistema de Coordenadas 3D")
    plt.show(block=False)

def plota_Questao3(vertices_cubo, vertices_piramide, new_cubo, new_piramide,
             translacao_nula, transformacao_nula, eye, centro_massa):

    #Inicialização do plot

    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    fig.canvas.manager.set_window_title('Trabalho 02 - N2 - CG  - Item 02 - Apresentação dos Diversos Sólidos no Sistema de Coord. 3D')

    ax.set_xlabel('X')
    ax.set_ylabel('Y')
    ax.set_zlabel('Z')

    r = [-1,1]
    X, Y = np.meshgrid(r, r)

    # MUDANÇA: Em 2023 06 de Abril!
    #Eixos (Na versão mais atual do matplotlib tinha mudado a forma dos pontos! Esse site ajudou a adaptar: https://stackoverflow.com/questions/61641473/given-a-n-3-array-how-to-obtain-a-list-of-3-n-1-arrays)
    PlotaAresta([[6, 0, 0]], [[-6, 0, 0]], 'black',ax)
    PlotaAresta([[0, 6, 0]], [[0, -6, 0]], 'black',ax)
    PlotaAresta([[0, 0, 6]], [[0, 0, -6]], 'black',ax)

    #Limite dos plots
    axes = plt.gca()
    axes.set_xlim([-6, 6])
    axes.set_ylim([-6, 6])
    axes.set_zlim([-6, 6])

    PlotaPonto(centro_massa, 'black',ax)
    PlotaPonto(eye, 'blue',ax)
    
    PlotaSolido1(vertices_cubo, translacao_cubo, transformacao_cubo, 'green', 'green', 'g',ax)
    PlotaSolido2(vertices_piramide, translacao_piramide, transformacao_piramide, 'green', 'green', 'g',ax)    
    PlotaSolido1(new_cubo, translacao_nula, transformacao_nula, 'blue', 'blue', 'b',ax)
    PlotaSolido2(new_piramide, translacao_nula, transformacao_nula, 'blue', 'blue', 'b',ax)

    plt.title("Plot - Formas Geométricas do Item 03 - Em um mesmo Sistema de Coordenadas 3D")
    plt.show(block=False)

def Questao2():
    plota_Questao2(vertices_cubo, translacao_cubo, transformacao_cubo, vertices_retangulo, translacao_retangulo, transformacao_retangulo, vertices_piramide, translacao_piramide, transformacao_piramide, vertices_tronco, translacao_tronco, transformacao_tronco)


def Questao3():
    plota_Questao3(vertices_cubo, vertices_piramide, new_cubo, new_piramide, translacao_nula, transformacao_nula, eye, centro_massa)

'''

Questão 4

'''

#Volume de imagem
esquerda = -6
direita = -12
baixo = 1
cima = 7
perto = -3
longe = -9

P = np.array([[1, 0, 0, 0],
              [0, 1, 0, 0],
              [0, 0, 0, 0],
              [0, 0, 0, 1]])
Tcn = np.array([[2/(direita - esquerda), 0, 0, -((direita+esquerda)/(direita-esquerda))],
                [0, 2/(cima+baixo), 0, -((cima+baixo)/(cima-baixo))],
                [0, 0, 2/(longe-perto), -((longe+perto)/(longe-perto))],
                [0, 0, 0, 1]])
T_2D = np.dot(P, Tcn)

#Transformações para 2D
cubo_2d = ProjecaoOrtogonal(new_cubo, T_2D)
piramide_2d = ProjecaoOrtogonal(new_piramide, T_2D)

def Questao4():

    fig = plt.figure()
    fig.canvas.manager.set_window_title('Plot - Formas Geométricas do Item 04 - Em um mesmo Sistema de Coordenadas 3D')

    pontos_cubo_2d = cubo_2d

    pontos_piramide_2d = piramide_2d

    arestas_cubo_2d = [
        pontos_cubo_2d[0], pontos_cubo_2d[1], pontos_cubo_2d[2], pontos_cubo_2d[3],
        pontos_cubo_2d[0], pontos_cubo_2d[1], pontos_cubo_2d[5], pontos_cubo_2d[4],
        pontos_cubo_2d[0], pontos_cubo_2d[4], pontos_cubo_2d[5], pontos_cubo_2d[6],
        pontos_cubo_2d[7], pontos_cubo_2d[7], pontos_cubo_2d[6], pontos_cubo_2d[5],
        pontos_cubo_2d[1], pontos_cubo_2d[2], pontos_cubo_2d[3], pontos_cubo_2d[7],
        pontos_cubo_2d[6], pontos_cubo_2d[5], pontos_cubo_2d[1], pontos_cubo_2d[2],
        pontos_cubo_2d[6], pontos_cubo_2d[5], pontos_cubo_2d[4], pontos_cubo_2d[7],
        pontos_cubo_2d[3], pontos_cubo_2d[0]
    ]

    arestas_piramide_2d = [
        pontos_piramide_2d[0], pontos_piramide_2d[1], pontos_piramide_2d[2],
        pontos_piramide_2d[3], pontos_piramide_2d[4], pontos_piramide_2d[0],
        pontos_piramide_2d[1], pontos_piramide_2d[4], pontos_piramide_2d[1],
        pontos_piramide_2d[2], pontos_piramide_2d[4], pontos_piramide_2d[2],
        pontos_piramide_2d[3], pontos_piramide_2d[4], pontos_piramide_2d[3],
        pontos_piramide_2d[0], pontos_piramide_2d[4]
    ]

    xs0, ys0 = zip(*arestas_cubo_2d)
    xs1, ys1 = zip(*arestas_piramide_2d)

    plt.plot(xs0, ys0, label='Cubo Resultante - Em 2D')
    plt.plot(xs1, ys1, label='Pirâmide Resultante - Em 2D')
    plt.title("Trabalho 02 - N2 - CG  - Item 04 - Apresentação dos Tais Objetos no Sistema de Coord. 2D")
    plt.legend(loc='best')
    plt.show(block=False)

"""
*
*       ******************************************************
*  ~~~ Construção de Interface Gráfica com a biblioteca Tkinter ~~~
*       ******************************************************
*
"""

# Cria objeto "Tkinter"/"Tk"
root = Tk()

# Muda o ícone padrão da janela do Tkinter
icone_asset_url = resource_path('recursos/icone.ico')
root.iconbitmap(icone_asset_url)
  
# Ajusta geometria "padrão" da janela da interface criada no Tkinter
root.geometry("910x587")

# Altera o título da janela da interface criada no Tkinter
root.title("Trabalho 2 - Comp. Gráfica - João Gabriel & Gustavo Vasconcelos")
  
# Adicona Imagem como plano de fundo da janela da interface criada no Tkinter
bg_asset_url = resource_path('recursos/img_de_fundo.png')
bg = PhotoImage(file = bg_asset_url, master=root)
  
# Label que mostra a imagem de plano de fundo da janela
label1 = Label( root, image = bg)
label1.place(x = 0, y = 0)#posicionado na posição (0,0) da janela

# Define tamanho da fonte usada em todos os elementos da interface.
myFont = font.Font(size=4)

# Definindo mais imagens a serem usadas na interface

imagem_IFCE_on_asset_url = resource_path('recursos/img_icone_botao_IF_on.png')
imagem_IFCE_on = PhotoImage(file=imagem_IFCE_on_asset_url, master=root)
imagem_IFCE_off_asset_url = resource_path('recursos/img_icone_botao_IF_off.png')
imagem_IFCE_off = PhotoImage(file=imagem_IFCE_off_asset_url, master=root)

imagem_botoes_janela_do_item_01_asset_url = resource_path('recursos/img_icone_de_botao_janela_item_01.png')
imagem_botoes_janela_do_item_01 = PhotoImage(file=imagem_botoes_janela_do_item_01_asset_url, master=root)

imagem_botoes_info_link_asset_url = resource_path('recursos/img_icone_de_botao_info_link.png')
imagem_botoes_info_link = PhotoImage(file=imagem_botoes_info_link_asset_url, master=root) 

imagem_botoes_info_link_destaque_config_01_off_asset_url = resource_path('recursos/img_destaque_de_botao_info_off.png')
imagem_botoes_info_link_destaque_config_01_off = PhotoImage(file=imagem_botoes_info_link_destaque_config_01_off_asset_url, master=root)
imagem_botoes_info_link_destaque_config_01_on_asset_url = resource_path('recursos/img_destaque_de_botao_info_on.png')
imagem_botoes_info_link_destaque_config_01_on = PhotoImage(file=imagem_botoes_info_link_destaque_config_01_on_asset_url, master=root)
imagem_botoes_info_link_destaque_config_02_off_asset_url = resource_path('recursos/img_destaque_de_botao_info_2_off.png')
imagem_botoes_info_link_destaque_config_02_off = PhotoImage(file=imagem_botoes_info_link_destaque_config_02_off_asset_url, master=root)
imagem_botoes_info_link_destaque_config_02_on_asset_url = resource_path('recursos/img_destaque_de_botao_info_2_on.png')
imagem_botoes_info_link_destaque_config_02_on = PhotoImage(file=imagem_botoes_info_link_destaque_config_02_on_asset_url, master=root)

imagem_botoes_asset_url = resource_path('recursos/img_icone_de_botao.png')
imagem_botoes = PhotoImage(file=imagem_botoes_asset_url, master=root)

imagem_destaque_botao_off_asset_url = resource_path('recursos/img_destaque_de_botao_off.png')
imagem_destaque_botao_off = PhotoImage(file=imagem_destaque_botao_off_asset_url, master=root)
imagem_destaque_botao_on_asset_url = resource_path('recursos/img_destaque_de_botao_on.png')
imagem_destaque_botao_on = PhotoImage(file=imagem_destaque_botao_on_asset_url, master=root)

imagem1_referencia_botao_1_off_asset_url = resource_path('recursos/img_label_item_01_off.png')
imagem1_referencia_botao_1_off = PhotoImage(file=imagem1_referencia_botao_1_off_asset_url, master=root)
imagem1_referencia_botao_1_on_asset_url = resource_path('recursos/img_label_item_01_on.png')
imagem1_referencia_botao_1_on = PhotoImage(file=imagem1_referencia_botao_1_on_asset_url, master=root)

imagem2_referencia_botao_2_off_asset_url = resource_path('recursos/img_label_item_02_off.png')
imagem2_referencia_botao_2_off = PhotoImage(file=imagem2_referencia_botao_2_off_asset_url, master=root)
imagem2_referencia_botao_2_on_asset_url = resource_path('recursos/img_label_item_02_on.png')
imagem2_referencia_botao_2_on = PhotoImage(file=imagem2_referencia_botao_2_on_asset_url, master=root)

imagem3_referencia_botao_3_off_asset_url = resource_path('recursos/img_label_item_03_off.png')
imagem3_referencia_botao_3_off = PhotoImage(file=imagem3_referencia_botao_3_off_asset_url, master=root)
imagem3_referencia_botao_3_on_asset_url = resource_path('recursos/img_label_item_03_on.png')
imagem3_referencia_botao_3_on = PhotoImage(file=imagem3_referencia_botao_3_on_asset_url, master=root)

imagem4_referencia_botao_4_off_asset_url = resource_path('recursos/img_label_item_04_off.png')
imagem4_referencia_botao_4_off = PhotoImage(file=imagem4_referencia_botao_4_off_asset_url, master=root)
imagem4_referencia_botao_4_on_asset_url = resource_path('recursos/img_label_item_04_on.png')
imagem4_referencia_botao_4_on = PhotoImage(file=imagem4_referencia_botao_4_on_asset_url, master=root)

# Definindo os labels que serão distribuídos e usados na interface da janela "principal" da aplicação
label_destaque_botao_1 = Label( root, image = imagem_destaque_botao_off) # << Imagem que o label irá usar
label_destaque_botao_1.place(x = 525, y = 350) # << Posição do label na janela principal

label_referencia_botao_1 = Label( root, image = imagem1_referencia_botao_1_off)
label_referencia_botao_1.place(x = 665, y = 345)

label_destaque_botao_2 = Label( root, image = imagem_destaque_botao_off)
label_destaque_botao_2.place(x = 525, y = 415)

label_referencia_botao_2 = Label( root, image = imagem2_referencia_botao_2_off)
label_referencia_botao_2.place(x = 665, y = 410)

label_destaque_botao_3 = Label( root, image = imagem_destaque_botao_off)
label_destaque_botao_3.place(x = 525, y = 480)

label_referencia_botao_3 = Label( root, image = imagem3_referencia_botao_3_off)
label_referencia_botao_3.place(x = 665, y = 475)

label_destaque_botao_4 = Label( root, image = imagem_destaque_botao_off)
label_destaque_botao_4.place(x = 525, y = 545)

label_referencia_botao_4 = Label( root, image = imagem4_referencia_botao_4_off)
label_referencia_botao_4.place(x = 665, y = 540)

# Definindo os métodos usados em eventos de interação entre o mouse e alguns elementos(mouse, labels e botões) da interface principal(Chamada aqui de "Root" mesmo rsrs) 
# e secundárias(Chamadas aqui de "Toplevels").
def muda_aparencia_label_IFCE_ON(event):
    labelIFCE.config(image=imagem_IFCE_on)
def muda_aparencia_label_IFCE_OFF(event):
    labelIFCE.config(image=imagem_IFCE_off)

def muda_aparencia_destaques_botao_01_ON(event):
    label_destaque_botao_1.config(image=imagem_destaque_botao_on)
    label_referencia_botao_1.config(image=imagem1_referencia_botao_1_on)
def muda_aparencia_destaques_botao_01_OFF(event):
    label_destaque_botao_1.config(image=imagem_destaque_botao_off)
    label_referencia_botao_1.config(image=imagem1_referencia_botao_1_off)

def muda_aparencia_destaques_botao_02_ON(event):
    label_destaque_botao_2.config(image=imagem_destaque_botao_on)
    label_referencia_botao_2.config(image=imagem2_referencia_botao_2_on)
def muda_aparencia_destaques_botao_02_OFF(event):
    label_destaque_botao_2.config(image=imagem_destaque_botao_off)
    label_referencia_botao_2.config(image=imagem2_referencia_botao_2_off)

def muda_aparencia_destaques_botao_03_ON(event):
    label_destaque_botao_3.config(image=imagem_destaque_botao_on)
    label_referencia_botao_3.config(image=imagem3_referencia_botao_3_on)
def muda_aparencia_destaques_botao_03_OFF(event):
    label_destaque_botao_3.config(image=imagem_destaque_botao_off)
    label_referencia_botao_3.config(image=imagem3_referencia_botao_3_off)

def muda_aparencia_destaques_botao_04_ON(event):
    label_destaque_botao_4.config(image=imagem_destaque_botao_on)
    label_referencia_botao_4.config(image=imagem4_referencia_botao_4_on)
def muda_aparencia_destaques_botao_04_OFF(event):
    label_destaque_botao_4.config(image=imagem_destaque_botao_off)
    label_referencia_botao_4.config(image=imagem4_referencia_botao_4_off)

def muda_aparencia_botao_destaque_config_01_info_link_ON(event,label):
    label.config(image=imagem_botoes_info_link_destaque_config_01_on)
def muda_aparencia_botao_destaque_config_01_info_link_OFF(event,label):
    label.config(image=imagem_botoes_info_link_destaque_config_01_off)
def muda_aparencia_botao_destaque_config_02_info_link_ON(event,label):
    label.config(image=imagem_botoes_info_link_destaque_config_02_on)
def muda_aparencia_botao_destaque_config_02_info_link_OFF(event,label):
    label.config(image=imagem_botoes_info_link_destaque_config_02_off)

def mostra_janela_imagens_ITEM_01():

    newWindow = Toplevel(root)

    newWindow.title("New Window")

    newWindow.geometry("300x300")

    Label(newWindow,text ="Imagens - Item 1)", font=("Arial", 18)).pack()
    Label(newWindow,text ="///////////////////////////////////////////////////////", anchor='w').pack() 
    Label(newWindow,text ="</Sólidos pedidos no item: 1 - em CG>", fg = "Red").pack()
    Label(newWindow,text ="     # Os botões acima plotam as diferentes figuras\n pedidas no item 01).", fg = "Blue").place(x=5, y=245)

    button_info_link_01 = Button(newWindow,text = " { - Sólido 01: Cubo                                      }  ", image=imagem_botoes_janela_do_item_01, compound="left",command=Questao1_plota_somente_CUBO)
    button_info_link_01.place(x=5, y=80)
    label_destaque__info_link_botao_1 = Label(newWindow,image = imagem_botoes_info_link_destaque_config_01_off)
    label_destaque__info_link_botao_1.place(x = 260, y = 78)
    button_info_link_01.bind("<Enter>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_ON(event,label_destaque__info_link_botao_1)) # Aqui usamos a função "lambda" pois é assim que fazemos um "bind" de uma função com argumentos nela a um botão.
    button_info_link_01.bind("<Leave>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_OFF(event,label_destaque__info_link_botao_1))
    
    button_info_link_02 = Button(newWindow,text = " { - Sólido 02: Retângulo                              }  ", image=imagem_botoes_janela_do_item_01, compound="left",command=Questao1_plota_somente_RETANGULO)
    button_info_link_02.place(x=5, y=110)
    label_destaque__info_link_botao_2 = Label(newWindow,image = imagem_botoes_info_link_destaque_config_01_off)
    label_destaque__info_link_botao_2.place(x = 261, y = 108)
    button_info_link_02.bind("<Enter>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_ON(event,label_destaque__info_link_botao_2))
    button_info_link_02.bind("<Leave>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_OFF(event,label_destaque__info_link_botao_2))
    
    button_info_link_03 = Button(newWindow,text = " { - Sólido 03: Pirâmide                                }  ", image=imagem_botoes_janela_do_item_01, compound="left",command=Questao1_plota_somente_PIRAMIDE)
    button_info_link_03.place(x=5, y=140)
    label_destaque__info_link_botao_3 = Label(newWindow,image = imagem_botoes_info_link_destaque_config_01_off)
    label_destaque__info_link_botao_3.place(x = 261, y = 138)
    button_info_link_03.bind("<Enter>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_ON(event,label_destaque__info_link_botao_3)) 
    button_info_link_03.bind("<Leave>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_OFF(event,label_destaque__info_link_botao_3))
    
    button_info_link_04 = Button(newWindow,text = " { - Sólido 04: Tronco de Pirâmide              }  ", image=imagem_botoes_janela_do_item_01, compound="left",command=Questao1_plota_somente_TRONCO)
    button_info_link_04.place(x=5, y=170)
    label_destaque__info_link_botao_4 = Label(newWindow,image = imagem_botoes_info_link_destaque_config_01_off)
    label_destaque__info_link_botao_4.place(x = 262, y = 168)
    button_info_link_04.bind("<Enter>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_ON(event,label_destaque__info_link_botao_4))
    button_info_link_04.bind("<Leave>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_OFF(event,label_destaque__info_link_botao_4))

    button_info_link_05 = Button(newWindow,text = " {  - Todos os sólidos juntos no plano 3D\n  *(  Extra )                                                   }  ", image=imagem_botoes_janela_do_item_01, compound="left",command=Questao1_plota_todas_as_figuras)
    button_info_link_05.place(x=5, y=200)
    label_destaque__info_link_botao_5 = Label(newWindow,image = imagem_botoes_info_link_destaque_config_02_off)
    label_destaque__info_link_botao_5.place(x = 254, y = 198)
    button_info_link_05.bind("<Enter>", lambda event,:muda_aparencia_botao_destaque_config_02_info_link_ON(event,label_destaque__info_link_botao_5))
    button_info_link_05.bind("<Leave>", lambda event,:muda_aparencia_botao_destaque_config_02_info_link_OFF(event,label_destaque__info_link_botao_5))

# Os 4 métodos de nomes "mostra_janela_informativa_item_0x()" (sendo x os números 1 ao 4) se referem a criação das janelas que são criadas ao clicar
# nos botões com símbolo "@?" na interface da janela principal da aplicação. Os métodos usados nas configurações dos botões serão "relembrados" mais abaixo
# no código!
def mostra_janela_informativa_item_01():
    # Objeto do Tkinter de tipo "Toplevel" que iremos tratar como uma "nova janela" (Que chamamos anteriormente de janela "secundária")
    newWindow = Toplevel(root)

    # As configurações desse "Toplevel" são as mesmas que usamos para definir algumas características iniciais de uma janela normal do Tkinter (Como já fizemos para a "root")
    newWindow.title("New Window")
  
    newWindow.geometry("300x350")

    # Criamos os labels e botões usados nessa janela, bem como suas "bindings" (As bindings são ações que chamam funções quando certos elementos são detectados
    # como um clique de um botão do mouse em um elemento que tenha essa binding, um botão ou label, é com isso que ao passar o mouse em cima de um botão certos
    # elementos gráficos nas interfaces "mudam" suas aparências dando a ideia de que foram "selecionados" pelo cursor, isso, e outros efeitos mais).
    Label(newWindow,text ="1) Você sabe? 🌐",font=("Arial", 18)).pack()
    Label(newWindow,text ="///////////////////////////////////////////////////////", anchor='w').pack() 
    Label(newWindow,text ="</Definições importantes do item: 1 - em CG>", fg = "Red").pack()
    Label(newWindow,text ="# Os botões acima levam para websites informativos!\nSó use-os com conexão Internet 📶.", fg = "Blue").place(x=5, y=290)

    button_info_link_01 = Button(newWindow,text = "  { - O que é um sólido?                                }  ", image=imagem_botoes_info_link, compound="left")
    button_info_link_01.place(x=5, y=80)
    button_info_link_01.bind("<Button-1>", lambda e: callback("https://pactuando.files.wordpress.com/2014/10/classificac3a7c3a3o-das-figuras-sc3b3lidas.pdf"))# << O botão chama o método que abre um link da internet (Hyperlink) quando o cursor do mouse 'clicar' na área que o botão ocupa o click deve ser com o botão '1' do mouse (Por isso "1-Button") 
    label_destaque__info_link_botao_1 = Label(newWindow,image = imagem_botoes_info_link_destaque_config_01_off)
    label_destaque__info_link_botao_1.place(x = 256, y = 78)
    button_info_link_01.bind("<Enter>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_ON(event,label_destaque__info_link_botao_1))
    button_info_link_01.bind("<Leave>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_OFF(event,label_destaque__info_link_botao_1))
    
    button_info_link_02 = Button(newWindow,text = "  { - Cubo?                                                      }  ", image=imagem_botoes_info_link, compound="left")
    button_info_link_02.place(x=5, y=110)
    button_info_link_02.bind("<Button-1>", lambda e: callback("https://pt.wikipedia.org/wiki/Cubo"))
    label_destaque__info_link_botao_2 = Label(newWindow,image = imagem_botoes_info_link_destaque_config_01_off)
    label_destaque__info_link_botao_2.place(x = 255, y = 108)
    button_info_link_02.bind("<Enter>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_ON(event,label_destaque__info_link_botao_2))
    button_info_link_02.bind("<Leave>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_OFF(event,label_destaque__info_link_botao_2))
    
    button_info_link_03 = Button(newWindow,text = "  { - Paralelepípedo?                                      }  ", image=imagem_botoes_info_link, compound="left")
    button_info_link_03.place(x=5, y=140)
    button_info_link_03.bind("<Button-1>", lambda e: callback("https://en.wikipedia.org/wiki/Parallelepiped"))
    label_destaque__info_link_botao_3 = Label(newWindow,image = imagem_botoes_info_link_destaque_config_01_off)
    label_destaque__info_link_botao_3.place(x = 255, y = 138)
    button_info_link_03.bind("<Enter>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_ON(event,label_destaque__info_link_botao_3))
    button_info_link_03.bind("<Leave>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_OFF(event,label_destaque__info_link_botao_3))
    
    button_info_link_04 = Button(newWindow,text = "  { - Pirâmide?                                                }  ", image=imagem_botoes_info_link, compound="left")
    button_info_link_04.place(x=5, y=170)
    button_info_link_04.bind("<Button-1>", lambda e: callback("https://en.wikipedia.org/wiki/Pyramid_(geometry)"))
    label_destaque__info_link_botao_4 = Label(newWindow,image = imagem_botoes_info_link_destaque_config_01_off)
    label_destaque__info_link_botao_4.place(x = 255, y = 168)
    button_info_link_04.bind("<Enter>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_ON(event,label_destaque__info_link_botao_4))
    button_info_link_04.bind("<Leave>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_OFF(event,label_destaque__info_link_botao_4))
    
    button_info_link_05 = Button(newWindow,text = "  { - Tronco de pirâmide?                             }  ", image=imagem_botoes_info_link, compound="left")
    button_info_link_05.place(x=5, y=200)
    button_info_link_05.bind("<Button-1>", lambda e: callback("https://pt.wikipedia.org/wiki/Tronco_(geometria)"))
    label_destaque__info_link_botao_5 = Label(newWindow,image = imagem_botoes_info_link_destaque_config_01_off)
    label_destaque__info_link_botao_5.place(x = 254, y = 198)
    button_info_link_05.bind("<Enter>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_ON(event,label_destaque__info_link_botao_5))
    button_info_link_05.bind("<Leave>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_OFF(event,label_destaque__info_link_botao_5))
    
    button_info_link_06 = Button(newWindow,text = "  { - Modelagem de sólidos?                       }  ", image=imagem_botoes_info_link, compound="left")
    button_info_link_06.place(x=5, y=230)
    button_info_link_06.bind("<Button-1>", lambda e: callback("https://www.inf.pucrs.br/~pinho/CG/Aulas/Modelagem/Modelagem3D.htm"))
    label_destaque__info_link_botao_6 = Label(newWindow,image = imagem_botoes_info_link_destaque_config_01_off)
    label_destaque__info_link_botao_6.place(x = 253, y = 228)
    button_info_link_06.bind("<Enter>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_ON(event,label_destaque__info_link_botao_6))
    button_info_link_06.bind("<Leave>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_OFF(event,label_destaque__info_link_botao_6))
    
    button_info_link_07 = Button(newWindow,text = "  { - Sistemas de coordenadas de objeto? }  ", image=imagem_botoes_info_link, compound="left")
    button_info_link_07.place(x=5, y=260)
    button_info_link_07.bind("<Button-1>", lambda e: callback("http://www.ic.uff.br/~anselmo/cursos/CGI/slidesGrad/CG_aula5(transformacoesnoplano).pdf"))
    label_destaque__info_link_botao_7 = Label(newWindow,image = imagem_botoes_info_link_destaque_config_01_off)
    label_destaque__info_link_botao_7.place(x = 252, y = 258)
    button_info_link_07.bind("<Enter>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_ON(event,label_destaque__info_link_botao_7))
    button_info_link_07.bind("<Leave>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_OFF(event,label_destaque__info_link_botao_7))

def mostra_janela_informativa_item_02():

    newWindow = Toplevel(root)

    newWindow.title("New Window")

    newWindow.geometry("300x300")

    Label(newWindow,text ="2) Você sabe? 🌐",font=("Arial", 18)).pack()
    Label(newWindow,text ="///////////////////////////////////////////////////////", anchor='w').pack() 
    Label(newWindow,text ="</Definições importantes do item: 2 - em CG>", fg = "Red").pack()
    Label(newWindow,text ="# Os botões acima levam para websites informativos!\nSó use-os com conexão Internet 📶.", fg = "Blue").place(x=5, y=200)

    button_info_link_01 = Button(newWindow,text = "  { - Sobreposição e intersecção?                 }  ", image=imagem_botoes_info_link, compound="left")
    button_info_link_01.place(x=5, y=80)
    button_info_link_01.bind("<Button-1>", lambda e: callback("https://knowledge.autodesk.com/pt-br/support/autocad-map-3d/learn-explore/caas/CloudHelp/cloudhelp/2019/PTB/MAP3D-Use/files/GUID-FF6F775E-D48B-489B-9469-1793789B79E8-htm.html"))
    label_destaque__info_link_botao_1 = Label(newWindow,image = imagem_botoes_info_link_destaque_config_01_off)
    label_destaque__info_link_botao_1.place(x = 257, y = 78)
    button_info_link_01.bind("<Enter>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_ON(event,label_destaque__info_link_botao_1))
    button_info_link_01.bind("<Leave>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_OFF(event,label_destaque__info_link_botao_1))
    
    button_info_link_02 = Button(newWindow,text = "  { - Sistemas de coordenadas do mundo? }  ", image=imagem_botoes_info_link, compound="left")
    button_info_link_02.place(x=5, y=110)
    button_info_link_02.bind("<Button-1>", lambda e: callback("https://web.tecgraf.puc-rio.br/tdk/tdk-tutorials/tdk-tutorial-basic/ref/ComputacaoGrafica1.pdf"))
    label_destaque__info_link_botao_2 = Label(newWindow,image = imagem_botoes_info_link_destaque_config_01_off)
    label_destaque__info_link_botao_2.place(x = 258, y = 108)
    button_info_link_02.bind("<Enter>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_ON(event,label_destaque__info_link_botao_2))
    button_info_link_02.bind("<Leave>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_OFF(event,label_destaque__info_link_botao_2))
    
    button_info_link_03 = Button(newWindow,text = "  { - Octantes?                                                 }  ", image=imagem_botoes_info_link, compound="left")
    button_info_link_03.place(x=5, y=140)
    button_info_link_03.bind("<Button-1>", lambda e: callback("https://pt.wikipedia.org/wiki/Octante_(geometria_espacial)"))
    label_destaque__info_link_botao_3 = Label(newWindow,image = imagem_botoes_info_link_destaque_config_01_off)
    label_destaque__info_link_botao_3.place(x = 257, y = 138)
    button_info_link_03.bind("<Enter>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_ON(event,label_destaque__info_link_botao_3))
    button_info_link_03.bind("<Leave>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_OFF(event,label_destaque__info_link_botao_3))
    
    button_info_link_04 = Button(newWindow,text = "  { - Transformações de escala?                    }  ", image=imagem_botoes_info_link, compound="left")
    button_info_link_04.place(x=5, y=170)
    button_info_link_04.bind("<Button-1>", lambda e: callback("https://www.inf.pucrs.br/pinho/CG/Aulas/Vis2d/Instanciamento/Instanciamento.htm#:~:text=Transforma%C3%A7%C3%A3o%20de%20Escala&text=a%20escala%20ocorre%20sempre%20em,ap%C3%B3s%20a%20opera%C3%A7%C3%A3o%20de%20escala."))
    label_destaque__info_link_botao_4 = Label(newWindow,image = imagem_botoes_info_link_destaque_config_01_off)
    label_destaque__info_link_botao_4.place(x = 258, y = 168)
    button_info_link_04.bind("<Enter>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_ON(event,label_destaque__info_link_botao_4))
    button_info_link_04.bind("<Leave>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_OFF(event,label_destaque__info_link_botao_4))

def mostra_janela_informativa_item_03():

    newWindow = Toplevel(root)

    newWindow.title("New Window")

    newWindow.geometry("300x300")

    Label(newWindow,text ="3) Você sabe? 🌐",font=("Arial", 18)).pack()
    Label(newWindow,text ="///////////////////////////////////////////////////////", anchor='w').pack() 
    Label(newWindow,text ="</Definições importantes do item: 3 - em CG>", fg = "Red").pack()
    Label(newWindow,text ="# Os botões acima levam para websites informativos!\nSó use-os com conexão Internet 📶.", fg = "Blue").place(x=5, y=200)

    button_info_link_01 = Button(newWindow,text = "  { - Sistemas de coordenadas em 3D?         }  ", image=imagem_botoes_info_link, compound="left")
    button_info_link_01.place(x=5, y=80)
    label_destaque__info_link_botao_1 = Label(newWindow,image = imagem_botoes_info_link_destaque_config_01_off)
    label_destaque__info_link_botao_1.place(x = 260, y = 78)
    button_info_link_01.bind("<Button-1>", lambda e: callback("https://www.youtube.com/watch?v=6_AQD8fwN-o)"))
    button_info_link_01.bind("<Enter>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_ON(event,label_destaque__info_link_botao_1))
    button_info_link_01.bind("<Leave>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_OFF(event,label_destaque__info_link_botao_1))
    
    button_info_link_02 = Button(newWindow,text = "  { - Base vetorial?                                            }  ", image=imagem_botoes_info_link, compound="left")
    button_info_link_02.place(x=5, y=110)
    button_info_link_02.bind("<Button-1>", lambda e: callback("https://pt.wikipedia.org/wiki/Base_(%C3%A1lgebra_linear)s"))
    label_destaque__info_link_botao_2 = Label(newWindow,image = imagem_botoes_info_link_destaque_config_01_off)
    label_destaque__info_link_botao_2.place(x = 261, y = 108)
    button_info_link_02.bind("<Enter>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_ON(event,label_destaque__info_link_botao_2))
    button_info_link_02.bind("<Leave>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_OFF(event,label_destaque__info_link_botao_2))
    
    button_info_link_03 = Button(newWindow,text = "  { - Volume de visão?                                     }  ", image=imagem_botoes_info_link, compound="left")
    button_info_link_03.place(x=5, y=140)
    button_info_link_03.bind("<Button-1>", lambda e: callback("http://wiki.icmc.usp.br/images/c/cf/Rosane_CG_Pos_ApViewing.pdf"))
    label_destaque__info_link_botao_3 = Label(newWindow,image = imagem_botoes_info_link_destaque_config_01_off)
    label_destaque__info_link_botao_3.place(x = 261, y = 138)
    button_info_link_03.bind("<Enter>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_ON(event,label_destaque__info_link_botao_3))
    button_info_link_03.bind("<Leave>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_OFF(event,label_destaque__info_link_botao_3))
    
    button_info_link_04 = Button(newWindow,text = "  { - Centro de massa?                                     }  ", image=imagem_botoes_info_link, compound="left")
    button_info_link_04.place(x=5, y=170)
    button_info_link_04.bind("<Button-1>", lambda e: callback("https://sites.ifi.unicamp.br/lunazzi/files/2014/04/MiguelK-Rigitano_RF.pdf"))
    label_destaque__info_link_botao_4 = Label(newWindow,image = imagem_botoes_info_link_destaque_config_01_off)
    label_destaque__info_link_botao_4.place(x = 262, y = 168)
    button_info_link_04.bind("<Enter>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_ON(event,label_destaque__info_link_botao_4))
    button_info_link_04.bind("<Leave>", lambda event,:muda_aparencia_botao_destaque_config_01_info_link_OFF(event,label_destaque__info_link_botao_4))

def mostra_janela_informativa_item_04():

    newWindow = Toplevel(root)

    newWindow.title("New Window")

    newWindow.geometry("300x300")

    Label(newWindow,text ="4) Você sabe? 🌐",font=("Arial", 18)).pack()
    Label(newWindow,text ="///////////////////////////////////////////////////////", anchor='w').pack() 
    Label(newWindow,text ="</Definições importantes do item: 4 - em CG>", fg = "Red").pack()
    Label(newWindow,text ="# Os botões acima levam para websites informativos!\nSó use-os com conexão Internet 📶.", fg = "Blue").place(x=5, y=120)

    button_info_link_01 = Button(newWindow,text = "  { - Transformação de projeção\n paralela ortogonal dos sólidos? }  ", image=imagem_botoes_info_link, compound="left")
    button_info_link_01.place(x=5, y=80)
    button_info_link_01.bind("<Button-1>", lambda e: callback("https://docente.ifrn.edu.br/joaocarmo/disciplinas/aulas/desenho-tecnico/projecoes-paralelas"))
    label_destaque__info_link_botao_1 = Label(newWindow,image = imagem_botoes_info_link_destaque_config_02_off)
    label_destaque__info_link_botao_1.place(x = 207, y = 78)
    button_info_link_01.bind("<Enter>", lambda event,:muda_aparencia_botao_destaque_config_02_info_link_ON(event,label_destaque__info_link_botao_1))
    button_info_link_01.bind("<Leave>", lambda event,:muda_aparencia_botao_destaque_config_02_info_link_OFF(event,label_destaque__info_link_botao_1))

# Criação do "botão (Que na verdade é um label mesmo kkkk)" que é a LOGO DO IFCE na interface principal da aplicação,
# clique nele e "uma surpresa" bem legal vai ser mostrada :)
labelIFCE = Label( root, image = imagem_IFCE_off)
labelIFCE.place(x = 23, y = 23)
labelIFCE.bind("<Enter>", muda_aparencia_label_IFCE_ON)
labelIFCE.bind("<Leave>", muda_aparencia_label_IFCE_OFF)
labelIFCE.bind("<Button-1>", cria_IF_3d)

# No trabalho anterior o professor já foi informado de como se mexe nas configurações e definições dos botões no Tkinter pelo aluno João Gabriel, a equipe vai
# relembrá-lo de novo kkkkk:
  
# Adiciona 1 botão a janela:
#
#*   .1- O parâmetro 'root' se refere a que janela o botão faz parte, no Tkinter, "Root" é sempre a 'janela principal' da interface.
#*   .2- O parâmetro 'text' se refere a adicionar um texto no botão.
#*   .3- O parâmetro 'image' se refere a adicionar uma imagem ao botão, que deve ser de preferência um objeto do tipo 'PhotoImage' já definido anteriormente.
#*   .4- O parâmetro 'command' se refere a uma função chamada pelo botão ao clicarmos nele.
#*   .5- O parâmetro 'compound' se refere ao ajuste que fazemos dos elementos dentro de um botão, para ficarem organizados e ajustados.
#####
button1 = Button(root,text = "  {Ver Desenho}  ", font= ('Arial 8 '), image=imagem_botoes, compound="left",command=mostra_janela_imagens_ITEM_01)

# Posiciona o botão na sua janela de referência
button1.place(x=555, y=350)

# Adiciona as 'binds' ou 'ações' que o botão faz ao se interagir com ele:
button1.bind("<Enter>", muda_aparencia_destaques_botao_01_ON) # << O botão chama a função "muda_aparencia_destaques_botao_01_ON" quando o cursor do mouse 'entra' na área que o botão ocupa (Por isso "Enter")
button1.bind("<Leave>", muda_aparencia_destaques_botao_01_OFF)# << O botão chama a função "muda_aparencia_destaques_botao_01_OFF" quando o cursor do mouse 'sai' na área que o botão ocupa (Por isso "Leave")

# Criando e ajustando os outros botões da interface gráfica
button2 = Button(root,text = "  {Ver Desenho}  ", font= ('Arial 8 '), image=imagem_botoes, compound="left",command=Questao2)
button2.place(x=555, y=415)
button2.bind("<Enter>", muda_aparencia_destaques_botao_02_ON)
button2.bind("<Leave>", muda_aparencia_destaques_botao_02_OFF)

button3 = Button(root,text = "  {Ver Desenho}  ", font= ('Arial 8 '), image=imagem_botoes, compound="left",command=Questao3)
button3.place(x=555, y=480)
button3.bind("<Enter>", muda_aparencia_destaques_botao_03_ON)
button3.bind("<Leave>", muda_aparencia_destaques_botao_03_OFF)

button4 = Button(root,text = "  {Ver Desenho}  ", font= ('Arial 8 '), image=imagem_botoes, compound="left",command=Questao4)
button4.place(x=555, y=545)
button4.bind("<Enter>", muda_aparencia_destaques_botao_04_ON)
button4.bind("<Leave>", muda_aparencia_destaques_botao_04_OFF)

button_informativo_item_01 = Button(root,text = "@?",font= ('Arial 10 '),fg = "Blue",command=mostra_janela_informativa_item_01)
button_informativo_item_01.place(x=16, y=179)

button_informativo_item_02 = Button(root,text = "@?",font= ('Arial 10 '),fg = "Blue",command=mostra_janela_informativa_item_02)
button_informativo_item_02.place(x=16, y=383)

button_informativo_item_03 = Button(root,text = "@?",font= ('Arial 10 '),fg = "Blue",command=mostra_janela_informativa_item_03)
button_informativo_item_03.place(x=448, y=33)

button_informativo_item_04 = Button(root,text = "@?",font= ('Arial 10 '),fg = "Blue",command=mostra_janela_informativa_item_04)
button_informativo_item_04.place(x=448, y=184)

# Executa o Tkinter
root.mainloop()

